function test(n: number): void {
    console.warn(n);
}

test('a');