import { world } from "mojang-minecraft";

let [func, func1, counter1, counter2, bool, bool1] = [[], [], 0, 0, false, false];

export default class tickBuilder {
    constructor() {return this};
    onTick(fun) {
        if (!(fun instanceof Function)) throw new Error('Unknow function!', {cause: 'Not a function'});
        func[counter1] = fun; counter1 ++;
        this.startTick();
    };
    onChat(fun) {
        if (!(fun instanceof Function)) throw new Error('Unknow function!', {cause: 'Not a function'});
        func1[counter2] = fun; counter2++;
        this.startChat();
    }
    startTick() {
        if (bool) return;
        bool = true;
        world.events.tick.subscribe((data) => {
            func.forEach((v) => v(data));
        });
    };
    startChat() {
        if (bool1) return;
        bool1 = true;
        world.events.beforeChat.subscribe((data) => {
            func1.forEach((v) => v(data));
        });
    }
    /**
    start...() {
        if (boolN) return;
        boolN = true;
        world.events.(mojang-minecraft.event).subscribe((data) => {
            funN.forEach((v) => v(data);
        });
    }
    */
}