/**
* Custom Command Builder
* @author Choigame123
* Discord: Choigame 123#5666
* Youtube: https://youtube.com/channel/UCngsKdvRaKrMZG-ar2ToAmg
* Discord group: https://discord.gg/2dnE2uT49r
*/

import {
    Player,
    world
} from "mojang-minecraft";

Array.prototype.splice=function(){'use-strict';if(typeof arguments[0]!=="number"||typeof arguments[1]!=="number"||typeof arguments[2]!=="number")throw'Error: undefined value at .splice';if(arguments[1]-1>arguments[0])throw'Error: the delete number values is too big with this array';function setCenterArgs(argument){let center4832 =[];for(let ct4838 =3;ct4838<Infinity;ct4838++){;if(!argument[ct4838])break;center4832.push(argument[ct4838]);};return center4832?center4832:[];};let [first3253,center3284,last4996]=[this.slice(0,arguments[0]+1-arguments[1]),setCenterArgs(arguments),this.slice(arguments[0]+1,this.length)];return [first3253,center3284,last4996].flat((arguments[2]===0)?1:arguments[2]+1)};
Array.prototype.random=function(){return this[Math.floor(Math.random()*this.length)]};
function isNum(u6u3u2) {if(!u6u3u2)return false;let d6s8f3 =u6u3u2.match(/[a-zA-Z#₫__&+()*"':;!?]/gi),d7s3r5 =(d6s8f3 ===null)?0: d6s8f3.length;if(d7s3r5 >= 1)return false; for(let u2u3u4 of u6u3u2.split(''))if(isNaN(parseFloat(u2u3u4)-1) && u2u3u4 !== '.')return false; return true};

let all_cmd_name_only = [],all_cmd_full = [],all_alias = [],is_running = false,set_admin_tag,set_cmd_perfix,admin_tag = 'Admin',command_perfix = "-",i = 0;


function reboot([v,v1]) {
    admin_tag = v;
    command_perfix = v1;
    return;
}

function say_error(line) {
    throw new Error("Error at commandBuilder.js:" + line, {cause: "Unexpected data type"});
}

function error_ano(player, args, sub_command, error_pattern = []) {
    console.warn('error')
    error_pattern = arg;
    error_pattern = error_pattern.splice(1, 0, 0, ">>>");
    error_pattern = error_pattern.splice(3, 0, 0, "<<<");
    if (sub_command.length === 0)
        return player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cCommand error at: §f${error_pattern.join(' ')}§c, this command hasn't args!"}]}`);
    return player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cCommand error at: §f${error_pattern.join(' ')}§c, arg:§a${args[2]}§c is unvalid argument, did you mean:§b ${sub_command_array.random()}"}]}`)
}

console.warn(`§cCustom command builder by Choigame123`);

/**
*
* Include things that make a custom command,
* easy to use(like mojang-minecraft-ui), no API
* @owner Choigame123
*
* @example
* let cmd = new customCommandBuilder()
* .command('Hi')
* .callBack((player, args) => {
*   console.warn('Hello world')
* });
*
*/
export default class customCommandBuilder {
    /**
     * @param {boolean} data If true, it will return this class (allows to get the value in class without creating an empty command)
     * @return {customCommandBuilder}
     */
    constructor(data = false) {
        if (data) return this;
        this.counter = i; i++;
        this.command_text = '';
        this.alias_array = [];
        this.usage_array = [];
        this.admin_only_bool = false;
        this.sub_command_array = [];
        this.category_type = 'no category';
        this.callBack_function = (player, args) => {};
        this.error_text = `Unknown command, please use ${command_perfix}help for more information`
        this.description_object = {
            describe: '',
            example: [],
            version: '',
            owner: []
        };
        return this;
    };
    /**
     * set a new data of command perfix and admin tag
     * Only one time even another files
     * @param {array} v [command_perfix, admin_tag]
     */
    set(data) {
        if (Array.isArray(data) || data.length === 2) {
            reboot(data);
        }
        return this;
    }
    /**
     * Return array of command name
     */
    get_all_cmd_name() {
        console.warn(all_cmd_name_only);
        return all_cmd_name_only;
    };
    /**
     * Return all command register
     */
    get_all_cmd() {
        return all_cmd_full;
    };
    /**
    * @private
    * use to update new change of command
    */
    _update() {
        all_cmd_name_only[this.counter] = this.command_text;
        all_alias[this.counter] = [this.command_text,
            this.alias_array].flat(2);
        all_cmd_full[this.counter] = {
            command: this.command_text,
            alias: this.alias_array,
            usage: this.usage_array,
            sub_cmd: this.sub_command_array,
            admin: this.admin_only_bool,
            category: this.category_type,
            callBack: this.callBack_function,
            error_text: this.error_text,
            description: this.description_object
        };
        this.start();
    };
    /**
    * Add label of command
    * @param {string} v a command label
    * @return {customCommandBuilder}
    */
    command(v) {
        if (typeof v !== "string") say_error(130);
        console.warn(`§aNew command builder:§b ${v}`);
        this.command_text = v;
        this._update();
        return this;
    };
    /**
    * Add alias for you command
    * @param {Array<string>} v array of alias
    * @return {customCommandBuilder}
    */
    alias(v) {
        if (!(v instanceof Array)) say_error(142);
        for (let v1 of v) if (typeof v1 !== "string") say_error(143);
        this.alias_array = v;
        this._update();
        return this;
    };
    /**
    * Add usage for you command(for help command)
    * @param {Array<string>} v array of usage
    * @return {customCommandBuilder}
    */
    usage(v) {
        if (!(v instanceof Array)) say_error(155);
        for (let v1 of v) if (typeof v1 !== "string") say_error(111);
        this.usage_array = v;
        this._update();
        return this;
    };
    /**
    * Add you sub-command (for auto check sub-command error)
    * @param {Array<string>} v array of sub-command
    * @return {customCommandBuilder}
    */
    sub_command(v) {
        if (!(v instanceof Array)) say_error(166);
        for (let v1 of v) if (typeof v1 !== "string") say_error(167);
        this.sub_command_array = v;
        this._update();
        return this;
    };
    /**
    * Set a permission for you command
    * @param {boolean} v If true, only admin tag can use this command
    * @return {customCommandBuilder}
    */
    admin_only(v) {
        if (typeof v !== "boolean") say_error(178);
        this.admin_only_bool = v;
        this._update();
        return this;
    };
    /**
    * Set category for you command (classify)
    * @param {string} v a category
    * @return {customCommandBuilder}
    */
    category(v) {
        if (typeof v !== "string") say_error(189);
        this.category_type = v;
        this._update();
        return this;
    };
    /**
    * Add description for you command
    * @param {string} v about command use to?
    * @param {Array<string>} v1 array of example how to use
    * @param {string} v2 command version
    * @param {Array<string>} v3 array of development
    * @return {customCommandBuilder}
    */
    description(v, v1, v2, v3) {
        if (typeof v !== "string" ||
            !(v1 instanceof Array) ||
            typeof v2 !== "string" ||
            !(v3 instanceof Array)) say_error(206);
        for (let v4 of v1) if (typeof v4 !== "string") say_error(207);
        for (let v5 of v3) if (typeof v5 !== "string") say_error(208);
        this.description_object = {
            describe: v,
            example: v1,
            version: v2,
            owner: v3
        };
        this._update();
        return this;
    };
    /**
    * Make a callback for you custom command
    * @param {function} func a callback: (player, args) => {}
    * @return {any} depending on your callback
    */
    callBack(func) {
        if (!(func instanceof Function)) say_error(224);
        this.callBack_function = func;
        this._update();
        return this;
    };
    /**
    * Make custom error message
    * @param {string} v custom error message
    */
    error_message(v) {
        if (typeof v !== "string") say_error(234);
        this.error_text = v;
        this._update();
        return this;
    };
    all_category(cmd = []) {
        for (let {category} of all_cmd_full) if (cmd.indexOf(category) === -1) cmd.push(category);
        return (cmd.length > 0) ? cmd: [];
    }
    /**
    * Get all command of category
    * @param {string} v category
    */
    get_cmd_category(v, cmd = [], output = []) {
        for (let {command, category} of all_cmd_full) if (category === v) cmd.push(command);
        if (cmd.length > 0) cmd.forEach((cd) => {
            output.push(all_cmd_full[all_cmd_name_only.indexOf(cd)]);
        });
        return output;
    };
    /**
    * Command helpler for category
    * @param {string} v category
    * @return {object}
    */
    help_category(player, v, cmd = [], output = []) {
        if (!this.all_category().includes(v)) return {error: true, data:null} 
        cmd = this.get_cmd_category(v);
        cmd.forEach((cd) => {
            output.push(this.help_one(cd.command).usage);
        });
        return {error: false, data: output};
    };
    /**
    * Specific command helper - for help command
    * @param {string} cmd label of command
    * @return {object} a help for command
    */
    help_one(cmd) {
        let index1 = all_cmd_name_only.indexOf(cmd);
        return (index1 === -1) ? {
            error: true,
            reson: `Unknown command`
        } : {
            error: false,
            usage: all_cmd_full[index1].usage,
            description: all_cmd_full[index1].description
        };
    };
    /**
    * All command helper - for help command
    * @param {number} page number of pages
    * @param {number} help_page_break_limit line number on a help page
    * @return {string} a help pages
    */
    help_all(page = 1, help_page_break_limit = Infinity) {
        let [counter, counter1, pages] = [0, 0, []];
        for (let it of all_cmd_full) {
            if (!pages[counter]) pages[counter] = new Array();
            pages[counter].push(it.usage.join("\n"))
            counter1++;
            if (counter1 >= help_page_break_limit) {
                counter++;
                counter1 = 0;
            }
        }
        if (page > counter + 1) page = 1;
        return `§a§l------ Showing the help page ${page} of ${counter + 1} (${command_perfix}help <page>) ------§r\n§f` + `${pages[page - 1].join("\n§f")}`;
    }
    /**
    * Start run all command builder
    * @attention please add this line in you chat rank to avoid error: "if (mes.split(" ")[0].startsWith(chat_cmd_perfix)) return data.cancel = true;"
    * @example
    * //you chat rank:
    * world.events.beforeChat.subsribe((data)=> {
    *     let [player, mes] = [data.sender, data.message];
    * //add line code here:
    * if (mes.split(" ")[0].startsWith(chat_cmd_perfix)) return data.cancel = true;
    * ...
    * });
    */
    start() {
        if (is_running) return;
        is_running = true;
        world.events.beforeChat.subscribe((data) => {
            let player = data.sender,
            chat = data.message;
            if (chat.startsWith(command_perfix)) {
                data.cancel = true;
                const args = [...chat.replace(command_perfix, "").split(/ /g)];
                for (let i = 0; i < all_alias.length; i++) {
                    if (all_alias[i].includes(args[0])) {
                        let command = all_cmd_full[i];
                        if (command.admin && !(player.hasTag(admin_tag))) return player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cYou don't have permission for use this command! Please check and try again."}]}`);
                        if (command.sub_cmd.length > 0 && !args[1]) error_ano(player, args, []);
                        if (!command.sub_cmd.includes(args[1]) && command.sub_cmd.length > 0) error_ano(player, args, command.sub_cmd);
                        return command.callBack(player, args);
                    }
                }
                return player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§c${this.error_text}"}]}`);
            }
        });
    }
}

const help_cmd = new customCommandBuilder()
    .command('help')
    .usage([`${command_perfix}help <command name: string>: show help for command you need`, `${command_perfix}help <page: int> : show all help`,`${command_perfix}help category <category: string>: show all help for category`])
    .alias(['h'])
    .admin_only(false)
    .sub_command([])
    .category('help')
    .description(`Help some command you don't know`, [`${command_perfix}help 1`,`${command_perfix}help help`,`${command_perfix}help category help`], '1.0.0', ['Choigame123'])
    .callBack((player, args) => {
        let helper = new customCommandBuilder(true);
        if (isNum(args[1]))
            player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§a${helper.help_all(args[1], 10)}"}]}`);
        else
        if (args[1] === 'category') {
            let {error, data} = helper.help_category(player, args[2]);
            if (error) return player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cNo category with name:§a '${args[2]}'§c. Did you mean:'§b${helper.all_category().random()}'§c?"}]}`);
            player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§aShow all help for category:§b ${args[2]}\n§f${data.join('\n§f')}"}]}`);
        }
        else {
            let helpCMD = helper.help_one(args[1]);
            if (!helpCMD.error) {
                let {usage, description} = helpCMD,
                    {describe, example, version, owner} = description;
                if (usage.length <= 0) usage = [`§cThis command haven't usage`];
                if (example.length <= 0) example = [`§cThis command haven't example`];
                if (describe.length <= 0) describe = `§fThis command haven't describe`;
                if (version.length <= 0) version = '0.0.0';
                if (owner.length <= 0) owner = ['anonymous'];
                player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§aShow help for command: §b${command_perfix}${args[1]}§a (v${version})§r\n§a§lDescription:§r\n§e${describe}\n§6Author:§4${owner.join(", ")}§r\n§l§aUsages:§r\n§f${usage.join('\n')}§r\n§a§lExample:§r§f\n${description.example.join('\n§f')}"}]}`);
            }
            else player.runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cNo command with name:§b '${args[1]}'§c. Did you mean:§a ${helper.get_all_cmd_name().random()}§c?"}]}`);
        }
    });