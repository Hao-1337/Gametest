import {
    Player,
    ItemStack,
    Items,
    MinecraftItemTypes,
    world,
    Entity,
    Location,
    BlockLocation,
    EntityQueryOptions
} from "mojang-minecraft";

let boolean = false, boolean1 = false;


export default class ChestFormBuilder {
    static startForm() {
        this.start();
    }
    onSM(entity) {
        this.entity = entity;
        console.warn(this.entity.id);
    }
    onM() {
        this.entity.addTag("is_chest_gui");
        this.entity.addTag(`gui_id:${this.player.nameTag}`);
        this.entity.triggerEvent("54_slot");
        this.entity.nameTag = "Shop";
        this.container = this.entity.getComponent("minecraft:inventory").container;
        for (let i = 0; i < 36; i++) this.container.setItem(i, (this.input[i] ? this.input[i]: new ItemStack(MinecraftItemTypes.air, 0, 0)));
        this.start();
    }
    constructor(player, location, container) {
        this.player = player;
        this.input = container;
        try {
            if (!boolean1) {
                boolean1 = true;
                let idkv = world.events.entityCreate.subscribe(({
                    entity
                }) => {
                    if (entity.id === "choigame:inventory") {
                        this.onSM(entity);
                    }
                });
            }
            if (!Array.isArray(container)) throw new Error('Must be container');
            player.triggerEvent("Script:spawn_chest_gui");
            setTickTimeOut(700, () => this.onM());
        } catch(e) {
            console.warn(e, e.stack)
        }
    };;
    start() {
        if (boolean) return;
        boolean = true;
        world.events.tick.subscribe(() => {})
    }
}
    function setTickTimeOut(ms, func) {
        let tick = ms / 1000 * 20;
        let set_tick_time_out = world.events.tick.subscribe(() => {
            tick--;
            if (tick <= 0) {
                world.events.tick.unsubscribe(set_tick_time_out);
                return func();
            }
        })
    }
    function newObj(obj) {
        if (typeof obj != "object") return obj;
        const _a = Array.isArray(obj) ? []: {};

        for (const k in obj) _a[k] = typeof obj == "object" ? newObj(obj[k]): obj[k];
        return _a;
    }

    function toString(obj) {
        return JSON.stringify(newObj(obj), void 0, 3);
    }