import { Items, MinecraftItemTypes } from "mojang-minecraft";
import {
    runCommands,
    getScore
 } from "../system/system.js";

 /**
  * Controller for shop sell item 
  * @param {Player} player mojang-minecraft-player
  * @param {Items.id} sell_item item id
  * @param {number} sell_count 
  * @param {Items.data} sell_data data value of item
  * @param {number} sell_cost 
  * @param {string} sell_name 
  * @param {string} sell_objective 
  * @returns 
  */
export function sellItem(player, sell_item, sell_count, sell_data, sell_cost, sell_name, sell_objective = "money") {
    let inventory = player.getComponent('minecraft:inventory').container,
    counter = 0;
    for (let i = 0; i < inventory.size; i++) {
       let item = inventory.getItem(i); if (!item) continue;
       if (item.id === sell_item && item.data === sell_data) counter += item.amount;
     }
    if (sell_count === 'all') sell_count = counter;
    if (counter < sell_count) return {complete: false, error: `§cYou not enough items to sell`};
    console.warn(`Sell item counter: ${counter}, Command:clear "${player.nameTag}" ${sell_item} ${sell_data} ${sell_count}`);
    runCommands([
        `clear "${player.nameTag}" ${sell_item} ${sell_data} ${sell_count}`,
        `scoreboard players add "${player.nameTag}" ${sell_objective} ${sell_count * sell_cost}`
        ]);
    return {complete: true, error: `§aYou get ${sell_count * sell_cost}$ by sell ${sell_count} ${sell_name}!`, data: {player: player, invoice: `${sell_item} ${sell_count} ${sell_data}`}};
 }

 /**
  * Controller for shop buy item
  * @param {Player} player mojang-minecraft-player
  * @param {Items.id} buy_item item id
  * @param {number} buy_count 
  * @param {Items.data} buy_data data value of item
  * @param {number} buy_cost 
  * @param {string} buy_name 
  * @param {stirng} buy_objective 
  * @returns 
  */
 export function buyItem(player, buy_item, buy_count, buy_data, buy_cost, buy_name, buy_objective = "money") {
     if (getScore(player, buy_objective) < buy_count * buy_cost) return {complete: false, error: "§cYou not enough money to buy!"};
     let inventory_object = [];
     let inventory1 = player.getComponent('minecraft:inventory').container;
     for (let i = 0; i < inventory1.size; i++) {
         let item1 = inventory1.getItem(i);
         if (!item1) item1 = 0;
         inventory_object.push({
             slot: i, data: item1
         });
     }
     let item_check = inventory_object.filter((it) => {if (it['data'].id === buy_item && it['data'].amount < 64 && it['data'].data === buy_data) return true; else return false;})?.map((it) => it = {slot: it['slot'], amount: it['data'].amount}),
     counter1 = 64 * inventory1.emptySlotsCount;
     if (item_check) for (let do_item_check of item_check) {
         counter1 += 64 - do_item_check['amount'];
     }
     if (buy_count > counter1) return {complete: false, error: "§cYou not enough slot to buy!"};
     console.warn(`Empty slot counter: ${counter1}`, `Command: give "${player.nameTag}" ${buy_item} ${buy_count} ${buy_data}`);
     runCommands([
         `give "${player.nameTag}" ${buy_item} ${buy_count} ${buy_data}`,
         `scoreboard players remove "${player.nameTag}" ${buy_objective} ${buy_count * buy_cost}`
     ]);
     return {complete: true, error: `§aYou bought ${buy_count} ${buy_name} with price ${buy_count * buy_cost}$`, data: {player: player, invoice: `${buy_item} ${buy_count} ${buy_data}`}};
 } 