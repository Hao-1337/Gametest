import Database from "../system/database.js";
import {
    Player,
    Entity
} from "mojang-minecraft";

let TEAM_DATA = new Database('team'),
ROM, ROM1, bool = false, p_log;

const UUIDGen = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c)=> {
    let r = (new Date().getTime()+Math.random()*16)%16|0; return(c == 'x'?r: (r&3|8)).toString(16);
});
function getEntityTag(entity, perfix) {
    let tags = entity.getTags()?.filter(tag => tag.startsWith(perfix))?.map(tag => tag.replace(perfix, ''))
    return (tags.length > 0)?tags: [];
}

export default class team() {
    constructor(team_name, member_count, team_owner) {
        if (this.allTeam().some((v) => v.key === team_name)) return {
            error: true,
            reson: `Early team has name: ${team_name}`
        };
        this.id = UUIDGen();
        team_owner.runCommand(`tag @s add "team_name:${team_name}"`);
        team_owner.runCommand(`tag @s add "team_id:${this.id}"`);
        this.team = {
            id: this.id
            name: team_name,
            owner: team_owner.nameTag,
            max_count: member_count,
            member: [team_owner.nameTag]
        }
        TEAM_DATA.set(team_name, this.team);
    };
    allTeam(){return TEAM_DATA.allKey()};
};
export function removeTeam(team_name, team_id) {
    let $t = TEAM_DATA.allKey().filter(v => v.name === team_name && v.id === team_id);
    if ($t.length > 1) return new Error('There is more than one team with the same value!');
    $t[0].member.forEach(v => checker(v));
    TEAM_DATA.remove(team_name);
    
}

    export function memberJoin(team_name, member) {
        ROM = TEAM_DATA.allKey();
        if (!ROM.some(v => v.key === team_name)) return {
            error: true,
            statusMessage: `No team with name: ${team_name}`
        };
        ROM = TEAM_DATA.get(team_name);
        if (ROM.member.indexOf(member) !== -1) return;
        ROM.member.push(member.nameTag);
        TEAM_DATA.update(team_name, ROM);
        member.runCommand(`tag @s add "team_name:${team_name}"`);
        member.runCommand(`tag @s add "team_id:${ROM.id}"`);
        return {
            error: false,
            statusMessage: `You joined the team: ${team_name}`
        }
    }
    export function memberLeft(team_name, member) {
        ROM1 = TEAM_DATA.allKey();
        if (!ROM1.some(v => v.key === team_name)) return {
            error: true,
            statusMessage: `No team with name: ${team_name}`
        };
        ROM1 = TEAM_DATA.get(team_name);
        if (ROM1.member.indexOf(member) !== -1) return;
        ROM1.member = ROM1.member.splice(ROM1.member.indexOf(member.nameTag), 1, 0);
        TEAM_DATA.update(team_name, ROM);
        member.runCommand(`tag @s remove "team_name:${team_name}"`);
        member.runCommand(`tag @s remove "team_id:${ROM1.id}"`);
        return {
            error: false,
            statusMessage: `You left the team: ${team_name}`
        }
    }

    function checker(player) {
        let [$team_render,
            $team_name,
            $team_id] = [getEntityTag(player, 'team:')[0],
            getEntityTag(player, "team_name:")[0],
            getEntityTag(player, "team_id:")[0]]
        try {
            if (!TEAM_DATA.allKey().some(v => v.key === $team_name)) {
                player.runCommand(`tag @s remove "team_name:${team_name}"`);
                player.runCommand(`tag @s remove "team_id:${$team_id}"`);
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§cYour team has been removed!"}]}`)
            }
        } catch(e) {} finally {
            try {
                player.runCommand(`tag @s remove "team_id:${$team_id}"`)
            } catch(e) {}
        }
    }

    world.events.playerJoin.subscribe((player) => {
        let wait = world.events.tick.subscribe(() => {
            function playerRunCommand(player) {
                try {
                    player.runCommand('testfor @s');
                    return true;
                } catch (e) {
                    return false;
                }
            };
            if (playerRunCommand(player)) {
                world.events.tick.unsubscribe(wait);
                checker(player);
            }
        });
    });

    /**
    so hard
    all line below is in development
    */

    world.events.tick.subscribe(() => {
        let $players = [], ALL_TEAM = [], TEAM = [], $counter = 0;
        for (let dim of ['overworld', 'nether', 'the end']) world.getDimension(dim).getPlayers().forEach(pl => $players.push(pl));
        for (let $p of $players) {
            let $team = getEntityTag($p, 'team_id:');
            ALL_TEAM.push($team)
        }
        ALL_TEAM = [...new Set(ALL_TEAM)] ?? [];
        ALL_TEAM.forEach((v, $new_id) => {
            let $team_pl = [...$players.filter(p => getEntityTag(p, "team_id:") === v)],
            $old_id = getEntityTag($team_pl[0], "team:")[0];
            try {
                $team_pl.forEach((p) => p.runCommand(`tag @s add "team:${$new_id}"`));
                $team_pl.forEach((p) => p.runCommand(`tag @s remove "team:${$old_id}"`));
            } catch(e) {}
        })
    });