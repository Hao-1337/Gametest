import {
    runCommand
} from "../system/system.js";
import {
    config
} from "../config.js";
import {
    Cuboid
} from "./CuboidBuilder.js";

//Structure class
export class Structure {
    constructor(prefix, pos1, pos2) {
        this.id = "save_tick";
        this.id1 = "load_tick";
        this.prefix = `${prefix}`;
        this.pos1 = pos1;
        this.pos2 = pos2;
        this.files = [];
        console.warn(runCommand(`tickingarea add ${this.pos1.x} ${this.pos1.y} ${this.pos1.z} ${this.pos2.x} ${this.pos2.y} ${this.pos2.z} ${this.id} true`).statusMessage);
        this.save();
    }
    save() {
        this.files = [];
        sleep(2000);
        const regions = new Cuboid(this.pos1, this.pos2).split(config.STRUCTURE_CHUNK_SIZE);
        for (const region of regions) {
            const name = `${this.prefix}_${regions.indexOf(region)}`;
            const pos1 = region.pos1;
            const pos2 = region.pos2;
            console.warn(runCommand(
                `structure save ${name} ${pos1.x} ${pos1.y} ${pos1.z} ${pos2.x} ${pos2.y} ${pos2.z} memory`
            ).statusMessage);
            this.files.push({
                name: name,
                pos1: pos1,
                pos2: pos2,
            });
        }
        console.warn(runCommand(`tickingarea remove ${this.id}`).statusMessage);
    }
    async on_load(pos3, pos4) {
        try {
            let e = new Cuboid(pos3, pos4),
            regions1 = combie(this.files, [...e.split(config.STRUCTURE_CHUNK_SIZE)]),
            e1 = distance(this.files[0].pos1, this.files[this.files.length -1].pos2);
            if (distance(pos3, pos4) != e1) throw `error:Two areas are not equal to load`;
            else {
                console.warn(runCommand(`tickingarea add ${pos3.x} ${pos3.y} ${pos3.z} ${pos4.x} ${pos4.y} ${pos4.z} ${this.id1} true`).statusMessage);
                sleep(2000);
                for (let region1 of regions1) {
                    console.warn(runCommand(`structure load ${region1.name} ${region1.pos.x} ${region1.pos.y} ${region1.pos.z} 0_degrees none block_by_block`).statusMessage);
                    sleep(2000);
                }
                console.warn(runCommand(`tickingarea remove ${this.id1}`).statusMessage);
            }
        } catch (error) {
            console.warn(error, error.stack)
        }
    }
}

//Measure distance
function distance(loc1, loc2) {
    const x = [loc1.x,
        loc2.x].sort((a, b) => b - a);
    const y = [loc1.y,
        loc2.y].sort((a, b) => b - a);
    const z = [loc1.z,
        loc2.z].sort((a, b) => b - a);
    return (x[0] - x[1]) * (y[0] - y[1]) * (z[0] - z[1]);
}

//Compact loader
function combie(a, b) {
    let c = [],
    d = 0;
    for (let region1 of a) {
        c.push({
            name: region1.name, pos: b[d].pos1
        });
        d++;
    }
    console.warn(toString(c));
    return c;
}

//sleep
function sleep(milliseconds) {
    const date = Date.now();
    let currentDate = null;
    do {
        currentDate = Date.now();
    } while (currentDate - date < milliseconds);
}

//console log check
function newObj(obj) {
    if (typeof obj != "object") return obj;
    const _a = Array.isArray(obj) ? []: {};

    for (const k in obj) _a[k] = typeof obj == "object" ? newObj(obj[k]): obj[k];
    return _a;
}

function toString(obj) {
    return JSON.stringify(newObj(obj), void 0, 3);
}