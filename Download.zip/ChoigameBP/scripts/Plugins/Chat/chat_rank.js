import {
    runCommand
} from "../../system/system.js";
import {
    Player
} from "mojang-minecraft";

export function chatRank(player, chat, rank, times) {
    if (!player.nameTag.startsWith('§')) {
        runCommand(`tellraw @a {"rawtext":[{"text":"§l§8[${times}§8][§r${rank}§l§8]§r§b ${player.nameTag}§f >§a ${chat}"}]}`);
    } else
    {
        runCommand(`tellraw @a {"rawtext":[{"text":"§l§8[${times}§8][§r${rank}§l§8]§r ${player.nameTag}§f >§a ${chat}"}]}`);
    }
}