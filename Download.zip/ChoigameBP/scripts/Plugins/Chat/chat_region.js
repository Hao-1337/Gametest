import {
    runCommand
} from "../../system/system.js";
import {
    setting
} from "../../config.js";
import {
    Player
} from "mojang-minecraft";

let chat_region_perfix = setting.chat_region_perfix;
let chatR = setting.chatR;

export function chatRegion(player, chat ,region, chat_rank, times) {
    if (chatR == false) {
        runCommand(`tellraw "${player.nameTag}" {"text":"§cPrivate chat is turned off, you can't chat!"}]}`);
        return;
    }
    if (!player.nameTag.startsWith('§')) {
        runCommand(`tellraw @a[tag="${chat_region_perfix}${region}"] {"rawtext":[{"text":"§l${region}§e§l>§r §l§8[§r${chat_rank}§l§8]§l§8[${times}§8]§r§b ${player.nameTag}§f >§a ${chat}"}]}`);
    } else
    {
        runCommand(`tellraw @a[tag="${chat_region_perfix}${region}"] {"rawtext":[{"text":"${region}§e§l>§r §l§8[§r${chat_rank}§l§8]§l§8[${times}§8]§r ${player.nameTag}§f >§a ${chat}"}]}`);

    }
}