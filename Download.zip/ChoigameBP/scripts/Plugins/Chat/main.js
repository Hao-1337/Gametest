import {
    chatRank
} from './chat_rank.js';
import {
    chatRegion
} from './chat_region.js';
import {
    setting
} from '../../config.js';
import {
    getRanks,
    getRegion,
    runCommand,
    runCommands,
    getScore,
    timeUpdate
} from '../../system/system.js';
import {
    world
} from 'mojang-minecraft';

import '../customcommand.js';

let saveCD = {},
chat_cmd_perfix = setting.command_perfix,
first_rank = setting.first_rank,
rank_perfix = setting.chat_rank_perfix,
region_perfix = setting.chat_region_perfix,
multi_rank_sign = setting.multirankSign,
rBool = setting.chatR,
timeCD = setting.timeCD;

export function onChat() {
    world.events.beforeChat.subscribe((data) => {
        try {
            let player = data.sender,
            chat = data.message;
            let time = timeUpdate(),
            rank = getRanks(player, rank_perfix, first_rank, multi_rank_sign),
            region = getRegion(player, region_perfix),
            bool = saveCD[player.nameTag] ?? false,
            rTagBool = region ? true : false;
            if (chat.split(" ")[0].startsWith(chat_cmd_perfix)) return data.cancel = true;
            if (bool) {
                data.cancel = true;
                return runCommand(`tellraw "${player.nameTag}" {"rawtext": [{"text":"§cYou chat so fast! Please wait more ${getScore(player, 'chatCD') / 20}s"}]}`);
            } else {
                data.cancel = true;
                onCoolDown(player);
                if (rBool && rTagBool) chatRegion(player, chat, region, rank, time);
                else chatRank(player, chat, rank, time);
            }
        } catch (error) {
            data.cancel = false;
            console.warn(error, error.stack);
        }
    });
}

function onCoolDown(player) {
    runCommands([
        `scoreboard objectives add chatCD dummy`,
        `scoreboard players set "${player.nameTag}" chatCD ${timeCD * 20}`,
    ]);
    let startCD = world.events.tick.subscribe(data => {
        runCommand(`execute "${player.nameTag}" ~~~ scoreboard players remove @s[scores={chatCD=0..}] chatCD 1`);
        if (getScore(player, 'chatCD') > 0) {
            saveCD[player.nameTag] = true;
        } else {
            world.events.tick.unsubscribe(startCD);
            saveCD[player.nameTag] = false;
        }
    });
    return;
}