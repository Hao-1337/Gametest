import ChestFormBuilder from "../../PluginsBuilder/chestGUIBuilder.js";
import customCommandBuilder from "../../PluginsBuilder/commandBuilder.js";
import { Items, ItemStack } from "mojang-minecraft";

let container = [
    new ItemStack(Items.get("minecraft:grass"), 1, 0),
    new ItemStack(Items.get("minecraft:netherite_block"), 1, 0)
    ];

let guitesst = new customCommandBuilder()
.command("gui")
.callBack(player => {
    try {
    return new ChestFormBuilder(player, player.location, container);
    } catch(e) {console.warn(e, e.stack)}
});