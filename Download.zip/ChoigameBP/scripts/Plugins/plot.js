import {
    BlockAreaSize,
    BlockInventoryComponent,
    BlockInventoryComponentContainer,
    BlockLocation as mcBL,
    EntityQueryOptions,
    EntityEventOptions,
    world,
    Location,
    BlockRaycastOptions
} from "mojang-minecraft";
import {
    config
} from "../config.js";

//These blocks need NBT
let nbtBlock = [
    "minecraft:acacia_standing_sign",
    "minecraft:birch_standing_sign",
    "minecraft:crimson_standing_sign",
    "minecraft:darkoak_standing_sign",
    "minecraft:jungle_standing_sign",
    "minecraft:mangrove_standing_sign",
    "minecraft:oak_standing_sign",
    "minecraft:spruce_standing_sign",
    "minecraft:warped_standing_sign",
    "minecraft:acacia_wall_sign",
    "minecraft:birch_wall_sign",
    "minecraft:crimson_wall_sign",
    "minecraft:darkoak_wall_sign",
    "minecraft:jungle_wall_sign",
    "minecraft:mangrove_wall_sign",
    "minecraft:oak_wall_sign",
    "minecraft:spruce_wall_sign",
    "minecraft:warped_wall_sign",
    "minecraft:shulker_box",
    "minecraft:barrel",
    "minecraft:undyed_shulker_box",
    "minecraft:respawn_anchor",
    "minecraft:smoker",
    "minecraft:blast_furnace",
    "minecraft:brewing_stand",
    "minecraft:soul_campfire",
    "minecraft:campfire",
    "minecraft:cauldron",
    "minecraft:composter",
    "minecraft:flower_pot",
    "minecraft:lectern",
    "minecraft:jukebox",
    "minecraft:noteblock",
    "minecraft:glow_frame",
    "minecraft:frame",
    "minecraft:beehive",
    "minecraft:beenest",
    "minecraft:dropper",
    "minecraft:dispenser",
    "minecraft:hopper",
    "minecraft:furnace",
    "minecraft:lit_furnace",
    "minecraft:lit_smoker",
    "minecraft:lit_blast_furnace",
],
special_nbtBlock = [
    "minecraft:chest",
    "minecraft:trapped_chest"
],
allnbtBlock = [special_nbtBlock, nbtBlock].flat(Infinity),
bypass_tag = config.admin_tag,
block_log = {},
timer = 0,
cli1 = new EntityQueryOptions();
cli1.type = "choigame:holder";
const cli2 = new EntityEventOptions();
cli2.type = ["minecraft:player"];

class nbtCheck {
    constructor() {
        this.start()};
    start() {
        this.check = world.events.tick.subscribe(() => {
            timer--;
            if (timer > - 10) return;
            timer = 10;
            for (let dim of ["overworld", "nether", "the end"]) {
                for (let e of [...world.getDimension(dim).getEntities(cli1)]) {
                    let [p,
                        $loc] = [e,
                        new mcBL(e.location.x - 0.6, e.location.y - 0.6, e.location.z - 0.6)],
                    $blk = e.dimension.getBlock($loc),
                    cli2 = new EntityQueryOptions();
                    cli2.location = new Location($loc.x, $loc.y, $loc.z);
                    cli2.type = "minecraft:player";
                    cli2.maxDistance = 18;
                    let check = [...new mcBL($loc.x - 1, $loc.y - 1, $loc.z - 1)
                        .blocksBetween(new mcBL($loc.x + 1, $loc.y + 1, $loc.z + 1))]
                    .map(v => v = e.dimension.getBlock(new mcBL(v.x, v.y, v.z)))
                    .filter(v => !(v.isEmpty));
                    if (!check.some(v => allnbtBlock.includes(v.id)) || [...e.dimension.getEntities(cli2)].length <= 0) {
                        e.kill();
                        continue;
                    }
                    for (let $bl of check) {
                        let loc = $bl.location;
                        if (nbtBlock.includes($bl.id)) {
                            try {
                                p.runCommand(`structure save "plot:${loc.x}|${loc.y}|${loc.z}" ${loc.x} ${loc.y} ${loc.z} ${loc.x} ${loc.y} ${loc.z} true disk true`);
                            } catch(e) {
                                console.warn(`NBT save error: ${e}`);
                            }
                        }
                        if (special_nbtBlock.includes($bl.id)) {
                            let $iv = $bl.getComponent('inventory').container;
                            block_log[`plot:${loc.x}|${loc.y}|${loc.z}`] = [];
                            for (let i = 0; i < $iv.size; i++) block_log[`plot:${loc.x}|${loc.y}|${loc.z}`][i] = $iv.getItem(i);
                        }
                    }
                }
            }
        });
    }
    stop() {
        world.events.tick.unsubscribe(this.check)
    }
}

let checkNBT = new nbtCheck();
/**
world.events.entityHit.subscribe(({entity, hitBlock, hitEntity}) => {
    
}, cli2);
world.events.blockPlace(({block, dimension, player}) => {
    
});
world.events.entityHurt(({cause, damage, damagingEntity, hurtEntity, projectile}) => {
    
});
*/
world.events.beforeItemUseOn.subscribe(({
    blockLocation,
    source
}) => {
    setTickTimeOut(2000, () => {
        for (let loc of new mcBL(blockLocation.x + 1, blockLocation.y + 1, blockLocation.z + 1).blocksBetween(new mcBL(blockLocation.x - 1, blockLocation.y - 1, blockLocation.z - 1))) {
            if (allnbtBlock.includes(source.dimension.getBlock(loc)?.id)) {
                let cli = new EntityQueryOptions();
                cli.location = new Location(loc.x, loc.y, loc.z);
                cli.type = "choigame:holder";
                cli.maxDistance = 1;
                if ([...source.dimension.getEntities(cli)].length > 0) return;
                source.dimension.spawnEntity("choigame:holder", loc);
            }
        }
    });
});
world.events.blockBreak.subscribe(
    ({
        block,
        brokenBlockPermutation,
        dimension,
        player
    }) => {
        let $b = brokenBlockPermutation.type;
        if (player.hasTag(bypass_tag))return;
        if (true) {
            dimension.getBlock(block.location)
            .setPermutation(brokenBlockPermutation.clone());
            //NBT block restore
            if (nbtBlock.includes($b.id)) {
                try {
                    player.runCommand(`structure load "plot:${block.x}|${block.y}|${block.z}" ${block.x} ${block.y} ${block.z} 0_degrees none false true`)
                } catch(e) {
                    console.warn(`Load NBT error: ${e}`)
                }
            }
            setTickTimeOut(20, () => {
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§cYou can do anything in player plot!"}]}`);
                const q = new EntityQueryOptions();
                q.maxDistance = 2;
                q.type = "minecraft:xp_orb";
                q.location = new Location(
                    block.location.x,
                    block.location.y,
                    block.location.z
                );
                const q1 = new EntityQueryOptions();
                q1.maxDistance = 2;
                q1.type = "minecraft:item";
                q1.location = new Location(
                    block.location.x,
                    block.location.y,
                    block.location.z
                );
                [...dimension.getEntities(q),
                    ...dimension.getEntities(q1)
                ].forEach((e) => e.kill());
            });
            if (special_nbtBlock.includes($b.id)) {
                checkNBT.stop();
                setTickTimeOut(60, () => {
                    let $inv = dimension.getBlock(block.location).getComponent('inventory').container,
                    $data = block_log[`plot:${block.x}|${block.y}|${block.z}`];
                    if (!$data) throw new Error(`No data found`);
                    for (let ii = 0; ii < $inv.size; ii++) {
                        if (!$data[ii]) continue;
                        $inv.setItem(ii, $data[ii]);
                    }
                });
                setTickTimeOut(70,
                    () => checkNBT.start());
            }
        }
    });

function setTickTimeOut(ms, func) {
    let tick = ms / 1000 * 20;
    let set_tick_time_out = world.events.tick.subscribe(() => {
        tick--;
        if (tick <= 0) {
            world.events.tick.unsubscribe(set_tick_time_out);
            return func();
        }
    })
}