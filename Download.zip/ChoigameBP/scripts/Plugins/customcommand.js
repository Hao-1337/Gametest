import customCommandBuilder from '../PluginsBuilder/commandBuilder.js';
import {
    Player, ItemStack, Items
} from "mojang-minecraft";
import {
    runCommand,
    runCommands
} from "../system/system.js";
import {
    lbUI
} from "./Form/leaderboardForm.js";
import {
   damgeToForm
} from "../system/system.js";

let get_ui_item = new customCommandBuilder()
.command('get_ui_item')
.alias(['get_ui_it','ui_it'])
.usage(['-get_ui_item : Use for get item for open UI if you lose it'])
.description('',[] , '1.0.0',['Choigame123'])
.callBack((player) => {
    //player.getComponent("minecraft:inventory").container.addItem(new ItemStack(Items.get("choigame123:ui_open"), 1, 0).setlore([]))
    runCommands([
        `replaceitem entity "${player.nameTag}" slot.hotbar 0 choigame123:ui_open 1 0 {"minecraft:item_lock":{"mode":"lock_in_inventory"},"minecraft:keep_on_death":{}}`,
        `tellraw "${player.nameTag}" {"rawtext":[{"text":"§aGave you ui item!"}]}`
        ]);
});

let leaderboard = new customCommandBuilder()
.command('leaderboard')
.alias(['ld'])
.usage(['-leaderboard : open UI for leaderboard'])
.description('',[] , '2.1.0',['Choigame123'])
.callBack((player) => {console.warn(player.nameTag);damgeToForm(player, (player) => {
      lbUI(player);
   });});


let lol = new customCommandBuilder()
.command("test")
.alias(['t'])
.callBack(player => player.runCommand(`say ${player.nameTag} this i test`));