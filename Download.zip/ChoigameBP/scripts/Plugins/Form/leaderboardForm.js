import { ActionFormData, ModalFormData } from "mojang-minecraft-ui";
import { runCommand, runCommands } from "../../system/system";

const leaderboard_ui = new ActionFormData()
    .title('§aLeaderBoard')
    .body('§bWhat do you want to do?')
    .button('§aCreate leaderboard', "textures/ui/add.png")
    .button('§cRemove leaderboard', "textures/ui/delete.png");
const leaderboard_ui_create = new ModalFormData()
    .title('§aCreate LeaderBoard')
    .textField('Name:', 'Enter name')
    .textField('Objective:', 'Enter objective')
    .textField('X position:', 'Enter X', '~')
    .textField('Y position:', 'Enter Y', '~')
    .textField('Z position:', 'Enter Z', '~')
    .toggle('Show in all time', false);
const leaderboard_ui_remove = new ModalFormData()
    .title('§cLeaderBoard Remove')
    .textField('Objective:', 'Enter objective')
    .textField('X position:', 'Enter X', '~')
    .textField('Y position:', 'Enter Y', '~')
    .textField('Z position:', 'Enter Z', '~');

export function lbUI(player) {
    leaderboard_ui.show(player).then((r1) => {
        if (r1.isCanceled === true) return;
        if (r1.selection === 0) addLB(player);
        if (r1.selection === 1) removeLB(player);
    });
}


function addLB(player) {
    leaderboard_ui_create.show(player).then((r2) => {
        if (r2.isCanceled === true) return lbUI(player);
        let X = r2.formValues[2];
        if (X === "~") X = Math.trunc(player.location.x);
        let Y = r2.formValues[3];
        if (Y === "~") Y = Math.trunc(player.location.y);
        let Z = r2.formValues[4]
        if (Z === "~") Z = Math.trunc(player.location.z);
        let bool1 = r2.formValues[5];
        let n1 = r2.formValues[0];
        let ob1 = r2.formValues[1];
        console.warn(`[Leaderboard] data:{"player":"${player.nameTag}","pos":[${X},${Y},${Z}],"name":"${n1}","objective":"${ob1}","show_all_time":${bool1}}`);
        let check = runCommand(`testfor @e[type=choigame:floating_text,x=${X},y=${Y},z=${Z},r=5,tag=is_leaderboard]`).statusMessage ?? undefined
        console.warn(`§bCheck leaderboard nearby: ${check}`);
        if (check === undefined) {
            console.warn(`[Leaderboard] §aAll thing are good, create leaderboard!`);
            runCommands([
                `summon choigame:floating_text "initializing" ${X} ${Y} ${Z}`,
                `tag @e[x=${X},y=${Y},z=${Z},r=2,type=choigame:floating_text] add is_leaderboard`,
                `tag @e[x=${X},y=${Y},z=${Z},r=2,type=choigame:floating_text] add "nameLB:${n1}"`,
                `tag @e[x=${X},y=${Y},z=${Z},r=2,type=choigame:floating_text] add "objective:${ob1}"`,
                `tag @e[x=${X},y=${Y},z=${Z},r=2,type=choigame:floating_text] add show_all_time:${bool1}`,
                `tellraw "${player.nameTag}" {"rawtext":[{"text":"§aCreate leaderboard with name:§f${n1} §aobjective:§f${ob1} §aat§e ${X} ${Y} ${Z} §asuccess!"}]}`,
                `playsound "${player.nameTag}" random.glass`,
            ]);
        } else {
            console.warn(`[Leatherboard] §cError because have a leaderboard nearby!`);
            runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"§cYou cannot place the leaderboard too close to another leaderboard"}]}`);
        }
    });
}

function removeLB(player) {
    leaderboard_ui_remove.show(player).then((r3) => {
        if (r3.isCanceled === true) return lbUI(player);
        let ob2 = r3.formValues[0];
        let X = r3.formValues[1];
        if (X === "~") X = Math.trunc(player.location.x);
        let Y = r3.formValues[2];
        if (Y === "~") Y = Math.trunc(player.location.y);
        let Z = r3.formValues[3]
        if (Z === "~") Z = Math.trunc(player.location.z);
        runCommands([
            `kill @e[type=choigame:floating_text,x=${X},y=${Y},z=${Z},r=3,tag="objective:${ob2}"]`,
            `tellraw "${player.nameTag}" {"rawtext":[{"text":"§aRemove leaderboard with objective:§f${ob1} §aat§e ${X} ${Y} ${Z} §asuccess!"}]}`,
            `playsound "${player.nameTag}" random.glass`,
        ]);
    });
}