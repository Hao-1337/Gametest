import {
   damgeToForm
} from "../../system/system.js";
import {
   ActionFormData,
   ModalFormData,
   MessageFormData
} from "mojang-minecraft-ui";
import { main_shop_ui_open } from "./shopForm.js";

export function openForm(player, boolean = false) {
   if (!boolean) damgeToForm(player, (player) => {
      mainForm(player);
   });
   else mainForm(player);
}
function mainForm(player) {
   menu_ui.show(player).then((r) => {
      switch (r.selection) {
         case 0: {
            return;
            break;
         };
         case 1: {
            return;
            break;
         };
         case 2: {
            return;
            break;
         };
         case 3: {
            main_shop_ui_open(player);
            break;
         };
         case 4: {
            return;
            break;
         };
         case 5: {
            return;
            break;
         };
         default: {
            return;
         }
      }
   });
}
//Main
const menu_ui = new ActionFormData()
.title('§l§b§k||§r§l§b Game Menu §b§k||§r')
.body("§aWellcome! Choose something you want!")
.button('Location')
.button('Teleport')
.button('Firends')
.button('Shop')
.button('Team')
.button('Admin');