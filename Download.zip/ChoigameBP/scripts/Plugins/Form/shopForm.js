import {
    buyItem,
    sellItem
} from "../../PluginsBuilder/UIShopBuilder";
import {
    numFormatter
} from "../../system/data_format";
import {
    ModalFormData,
    ActionFormData
} from "mojang-minecraft-ui";
import {
    runCommand
} from "../../system/system";
//===================================================================================================================================================================================================================================
//Declare data
//===================================================================================================================================================================================================================================

let cache = {},
    natural_blocks = [
        {
            name: "Dirt",
            id: 'minecraft:dirt',
            dv: 0,
            cost_buy: 1,
            cost_sell: 1,
            texture: "dirt.png"
        },
        {
            name: "Coarse Dirt",
            id: 'minecraft:dirt',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "coarse_dirt.png"
        },
        {
            name: "Grass",
            id: 'minecraft:grass',
            dv: 0,
            cost_buy: 3,
            cost_sell: 2,
            texture: "grass.png"
        },
        {
            name: "Podzol",
            id: 'minecraft:podzol',
            dv: 0,
            cost_buy: 3,
            cost_sell: 1,
            texture: "podzol.png"
        },
        {
            name: "Mycelium",
            id: 'minecraft:mycelium',
            dv: 0,
            cost_buy: 3,
            cost_sell: 1,
            texture: "mycelium.png"
        },
        {
            name: "Gravel",
            id: 'minecraft:gravel',
            dv: 0,
            cost_buy: 1,
            cost_sell: 1,
            texture: "gravel.png"
        },
        {
            name: "Sand",
            id: 'minecraft:sand',
            dv: 0,
            cost_buy: 1,
            cost_sell: 1,
            texture: "sand0.png"
        },
        {
            name: "Redsand",
            id: 'minecraft:sand',
            dv: 1,
            cost_buy: 2,
            cost_sell: 1,
            texture: "sand1.png"
        },
        {
            name: "Stone",
            id: 'minecraft:stone',
            dv: 0,
            cost_buy: 2,
            cost_sell: 1,
            texture: "stone.png"
        },
        {
            name: "Granite",
            id: 'minecraft:stone',
            dv: 1,
            cost_buy: 2,
            cost_sell: 1,
            texture: "granite.png"
        },
        {
            name: "Diorite",
            id: 'minecraft:stone',
            dv: 3,
            cost_buy: 2,
            cost_sell: 1,
            texture: "diorite.png"
        },
        {
            name: "Andesite",
            id: 'minecraft:stone',
            dv: 5,
            cost_buy: 2,
            cost_sell: 1,
            texture: "andesite.png"
        },
        {
            name: "Deepslate",
            id: 'minecraft:deepslate',
            dv: 0,
            cost_buy: 3,
            cost_sell: 1,
            texture: "deepslate.png"
        },
        {
            name: "Tuff",
            id: 'minecraft:tuff',
            dv: 5,
            cost_buy: 2,
            cost_sell: 1,
            texture: "tuff.png"
        },
        {
            name: "Amethyst Block",
            id: 'minecraft:amethyst_block',
            dv: 0,
            cost_buy: 10,
            cost_sell: 6,
            texture: "amethyst_block.png"
        },
        {
            name: "Budding Amethyst",
            id: 'minecraft:budding_amethyst',
            dv: 0,
            cost_buy: 3000,
            cost_sell: 1e9,
            special_number: true,
            texture: "budding_amethyst.png"
        },
        {
            name: "Calcite",
            id: 'minecraft:calcite',
            dv: 0,
            cost_buy: 11,
            cost_sell: 7,
            texture: "calcite.png"
        },
        {
            name: "Packed Ice",
            id: 'minecraft:frosted_ice',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "frosted_ice.png"
        },
        {
            name: "Blue Ice",
            id: 'minecraft:blue_ice',
            dv: 0,
            cost_buy: 13,
            cost_sell: 3,
            texture: "blue_ice.png"
        },
        {
            name: "Oak Log",
            id: 'minecraft:log',
            dv: 0,
            cost_buy: 5,
            cost_sell: 3,
            texture: "oak_log.png"
        },
        {
            name: "Spruce Log",
            id: 'minecraft:log',
            dv: 1,
            cost_buy: 5,
            cost_sell: 3,
            texture: "spruce_log.png"
        },
        {
            name: "Birch Log",
            id: 'minecraft:log',
            dv: 2,
            cost_buy: 5,
            cost_sell: 3,
            texture: "brich_log.png"
        },
        {
            name: "Jungle Log",
            id: 'minecraft:log',
            dv: 3,
            cost_buy: 5,
            cost_sell: 3,
            texture: "jungle_log.png"
        },
        {
            name: "Acacia Log",
            id: 'minecraft:log2',
            dv: 0,
            cost_buy: 5,
            cost_sell: 3,
            texture: "acacia_log.png"
        },
        {
            name: "Dark Oak Log",
            id: 'minecraft:log2',
            dv: 1,
            cost_buy: 5,
            cost_sell: 3,
            texture: "dark_oak_log.png"
        },
        {
            name: "Mangrove Log",
            id: 'minecraft:mangrove_log',
            dv: 1,
            cost_buy: 5,
            cost_sell: 3,
            texture: "mangrove_log.png"
        },
        {
            name: "Oak Leaves",
            id: 'minecraft:leaves',
            dv: 0,
            cost_buy: 1,
            cost_sell: 1,
            texture: "oak_leaves.png"
        },
        {
            name: "Spruce Leaves",
            id: 'minecraft:leaves',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "spruce_leaves.png"
        },
        {
            name: "Birch Leaves",
            id: 'minecraft:leaves',
            dv: 2,
            cost_buy: 1,
            cost_sell: 1,
            texture: "birch_leaves.png"
        },
        {
            name: "Jungle Leaves",
            id: 'minecraft:leaves',
            dv: 3,
            cost_buy: 1,
            cost_sell: 1,
            texture: "jungle_leaves.png"
        },
        {
            name: "Acacia Leaves",
            id: 'minecraft:leaves2',
            dv: 0,
            cost_buy: 1,
            cost_sell: 1,
            texture: "acacia_leaves.png"
        },
        {
            name: "Dark Oak Leaves",
            id: 'minecraft:leaves2',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "dark_oak_leaves.png"
        },
        {
            name: "Mangrove Leaves",
            id: 'minecraft:mangrove_leaves',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "mangrove_leaves.png"
        },
        {
            name: "Azalea Leaves",
            id: 'minecraft:azalea_leaves',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "azalea_leaves.png"
        },
        {
            name: "Flowering Azalea Leaves",
            id: 'minecraft:azalea_leaves_flowered',
            dv: 1,
            cost_buy: 1,
            cost_sell: 1,
            texture: "flowering_azalea_leaves.png"
        },
        {
            name: "Coal Ore",
            id: 'minecraft:coal_ore',
            dv: 0,
            cost_buy: 7,
            cost_sell: 4,
            texture: "coal_ore.png"
        },
        {
            name: "Iron Ore",
            id: 'minecraft:iron_ore',
            dv: 0,
            cost_buy: 20,
            cost_sell: 6,
            texture: "iron_ore.png"
        },
        {
            name: "Gold Ore",
            id: 'minecraft:gold_ore',
            dv: 0,
            cost_buy: 30,
            cost_sell: 9,
            texture: "gold_ore.png"
        },
        {
            name: "Redstone Ore",
            id: 'minecraft:redstone_ore',
            dv: 0,
            cost_buy: 12,
            cost_sell: 4,
            texture: "redstone_ore.png"
        },
        {
            name: "Lapis Lazuli Ore",
            id: 'minecraft:lapis_ore',
            dv: 0,
            cost_buy: 17,
            cost_sell: 4,
            texture: "lapis_ore.png"
        },
        {
            name: "Copper Ore",
            id: 'minecraft:copper_ore',
            dv: 0,
            cost_buy: 15,
            cost_sell: 4,
            texture: "copper_ore.png"
        },
        {
            name: "Diamond Ore",
            id: 'minecraft:diamond_ore',
            dv: 0,
            cost_buy: 50,
            cost_sell: 30,
            texture: "diamond_ore.png"
        },
        {
            name: "Emerald Ore",
            id: 'minecraft:emerald_ore',
            dv: 0,
            cost_buy: 70,
            cost_sell: 35,
            texture: "emerald_ore.png"
        },
        {
            name: "Deepslate Coal Ore",
            id: 'minecraft:deepslate_coal_ore',
            dv: 0,
            cost_buy: 8,
            cost_sell: 4,
            texture: "deepslate_coal_ore.png"
        },
        {
            name: "Deepslate Iron Ore",
            id: 'minecraft:deepslate_iron_ore',
            dv: 0,
            cost_buy: 21,
            cost_sell: 6,
            texture: "deepslate_iron_ore.png"
        },
        {
            name: "Deepslate Gold Ore",
            id: 'minecraft:deepslate_gold_ore',
            dv: 0,
            cost_buy: 31,
            cost_sell: 9,
            texture: "deepslate_gold_ore.png"
        },
        {
            name: "Deepslate Redstone Ore",
            id: 'minecraft:deepslate_redstone_ore',
            dv: 0,
            cost_buy: 13,
            cost_sell: 4,
            texture: "deepslate_redstone_ore.png"
        },
        {
            name: "Deepslate Lapis Lazuli Ore",
            id: 'minecraft:deepslate_lapis_ore',
            dv: 0,
            cost_buy: 18,
            cost_sell: 4,
            texture: "deepslate_lapis_ore.png"
        },
        {
            name: "Deepslate Copper Ore",
            id: 'minecraft:deepslate_copper_ore',
            dv: 0,
            cost_buy: 16,
            cost_sell: 4,
            texture: "deepslate_copper_ore.png"
        },
        {
            name: "Deepslate Diamond Ore",
            id: 'minecraft:deepslate_diamond_ore',
            dv: 0,
            cost_buy: 52,
            cost_sell: 30,
            texture: "deepslate_diamond_ore.png"
        },
        {
            name: "Deepslate Emerald Ore",
            id: 'minecraft:deepslate_emerald_ore',
            dv: 0,
            cost_buy: 73,
            cost_sell: 35,
            texture: "deepslate_emerald_ore.png"
        },
        {
            name: "Nether Quartz Ore",
            id: 'minecraft:quartz_ore',
            dv: 0,
            cost_buy: 11,
            cost_sell: 5,
            texture: "quartz_ore.png"
        },
        {
            name: "Nether Gold Ore",
            id: 'minecraft:nether_gold_ore',
            dv: 0,
            cost_buy: 10,
            cost_sell: 22,
            texture: "nether_gold_ore.png"
        },
        {
            name: "Ancient Debris",
            id: 'minecraft:ancient_debris',
            dv: 0,
            cost_buy: 120,
            cost_sell: 50,
            texture: "ancient_debris.png"
        },
    ],
    natural_items = [
        {
            name: "Oak Sapling",
            id: 'minecraft:sapling',
            dv: 0,
            cost_buy: 7,
            cost_sell: 1,
            texture: "oak_sapling.png"
        },
        {
            name: "Brich Sapling",
            id: 'minecraft:sapling',
            dv: 2,
            cost_buy: 7,
            cost_sell: 1,
            texture: "brich_sapling.png"
        },
        {
            name: "Spruce Sapling",
            id: 'minecraft:sapling',
            dv: 1,
            cost_buy: 7,
            cost_sell: 1,
            texture: "spruce_sapling.png"
        },
        {
            name: "Acacia Sapling",
            id: 'minecraft:sppling',
            dv: 4,
            cost_buy: 7,
            cost_sell: 1,
            texture: "acacia_sapling.png"
        },
        {
            name: "Dark Oak Sapling",
            id: 'minecraft:sapling',
            dv: 5,
            cost_buy: 7,
            cost_sell: 1,
            texture: "dark_oak_sapling.png"
        },
        {
            name: "Jungle Sapling",
            id: 'minecraft:sapling',
            dv: 3,
            cost_buy: 7,
            cost_sell: 1,
            texture: "jungle_sapling.png"
        },
        {
            name: "Mangrove Propagule",
            id: 'minecraft:mangrove_propagule',
            dv: 0,
            cost_buy: 8,
            cost_sell: 1,
            texture: "mangrove_sapling.png"
        },
        {
            name: "Cactus",
            id: 'minecraft:cactus',
            dv: 0,
            cost_buy: 10,
            cost_sell: 3,
            texture: "cactus.png"
        },
        {
            name: "Bamboo",
            id: 'minecraft:bamboo',
            dv: 0,
            cost_buy: 10,
            cost_sell: 4,
            texture: "bamboo.png"
        },
        {
            name: "Wheat seed",
            id: 'minecraft:wheat_seeds',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "wheat_seed.png"
        },
        {
            name: "Pumpkin Seed",
            id: 'minecraft:pumpkin_seeds',
            dv: 0,
            cost_buy: 9,
            cost_sell: 1,
            texture: "pumpkin_seed.png"
        },
        {
            name: "Melon Seed",
            id: 'minecraft:melon_seeds',
            dv: 0,
            cost_buy: 10,
            cost_sell: 1,
            texture: "melon_seed.png"
        },
        {
            name: "Beetroot Seed",
            id: 'minecraft:beetroot_seeds',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "beetroot_seed.png"
        },
        {
            name: "Potato",
            id: 'minecraft:potato',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "potato.png"
        },
        {
            name: "Carrot",
            id: 'minecraft:carrot',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "carrot.png"
        },
        {
            name: "Sweet Berries",
            id: 'minecraft:sweet_berries',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "sweet_berries.png"
        },
        {
            name: "Glow Berries",
            id: 'minecraft:glow_berries',
            dv: 0,
            cost_buy: 5,
            cost_sell: 1,
            texture: "glow_berries.png"
        },
        {
            name: "Moss Block",
            id: 'minecraft:moss_block',
            dv: 0,
            cost_buy: 3,
            cost_sell: 1,
            texture: "moss_block.png"
        },
        {
            name: "Moss Carpet",
            id: 'minecraft:moss_carpet',
            dv: 0,
            cost_buy: 0,
            cost_sell: 0,
            texture: "moss_carpet.png"
        },
        {
            name: "Azalea",
            id: 'minecraft:azalea',
            dv: 0,
            cost_buy: 6,
            cost_sell: 1,
            texture: "azalea.png"
        },
        {
            name: "Flowering Azalea",
            id: 'minecraft:flowering_azalea',
            dv: 0,
            cost_buy: 6,
            cost_sell: 1,
            texture: "flowering_azalea.png"
        },
        {
            name: "Small Dripleaf",
            id: 'minecraft:small_dripleaf_block',
            dv: 0,
            cost_buy: 10,
            cost_sell: 3,
            texture: "small_dripleaf.png"
        },
        {
            name: "Big Dripleaf",
            id: 'minecraft:big_dripleaf',
            dv: 0,
            cost_buy: 11,
            cost_sell: 3,
            texture: "big_dripleaf.png"
        },
        {
            name: "Spore Blossom",
            id: 'minecraft:spore_blossom',
            dv: 0,
            cost_buy: 30,
            cost_sell: 10,
            texture: "spore_blossom.png"
        },
        {
            name: "Kelp",
            id: 'minecraft:kelp',
            dv: 0,
            cost_buy: 7,
            cost_sell: 1,
            texture: "kelp.gif"
        },
        {
            name: "Seagrass",
            id: 'minecraft:seagrass',
            dv: 0,
            cost_buy: 4,
            cost_sell: 1,
            texture: "seagrass.gif"
        },
        {
            name: "Lily Pad",
            id: 'minecraft:waterlily',
            dv: 0,
            cost_buy: 6,
            cost_sell: 1,
            texture: "waterlily.png"
        }],
    building_blocks = [{
        name: "",
        id: 'minecraft:',
        dv: 0,
        cost_buy: 0,
        cost_sell: 0,
        texture: ""
    },
    ],
    tools = {
        tool_axes: [
            {
                name: "Wooden Axe",
                id: 'minecraft:wooden_axe',
                dv: 0,
                cost_buy: 2 * 3,
                cost_sell: 1 * 3,
                texture: "wooden_axe.png"
            },
            {
                name: "Stone Axe",
                id: 'minecraft:stone_axe',
                dv: 0,
                cost_buy: 3 * 3,
                cost_sell: 1 * 3,
                texture: "stone_axe.png"
            },
            {
                name: "Iron Axe",
                id: 'minecraft:iron_axe',
                dv: 0,
                cost_buy: 30 * 3,
                cost_sell: 20 * 3,
                texture: "iron_axe.png"
            },
            {
                name: "Golden Axe",
                id: 'minecraft:golden_axe',
                dv: 0,
                cost_buy: 40 * 3,
                cost_sell: 30 * 3,
                texture: "golden_axe.png"
            },
            {
                name: "Diamond Axe",
                id: 'minecraft:diamond_axe',
                dv: 0,
                cost_buy: 60 * 3,
                cost_sell: 50 * 3,
                texture: "diamond_axe.png"
            },
            {
                name: "Netherite Axe",
                id: 'minecraft:netherite_axe',
                dv: 0,
                cost_buy: 60 * 3 + 800,
                cost_sell: 50 * 3 + 800,
                texture: "netherite_axe.png"
            }
        ],
        tool_pickaxes: [
            {
                name: "Wooden Pickaxe",
                id: 'minecraft:wooden_pickaxe',
                dv: 0,
                cost_buy: 2 * 3,
                cost_sell: 1 * 3,
                texture: "wooden_pickaxe.png"
            },
            {
                name: "Stone Pickaxe",
                id: 'minecraft:stone_pickaxe',
                dv: 0,
                cost_buy: 3 * 3,
                cost_sell: 1 * 3,
                texture: "stone_pickaxe.png"
            },
            {
                name: "Iron Pickaxe",
                id: 'minecraft:iron_pickaxe',
                dv: 0,
                cost_buy: 30 * 3,
                cost_sell: 20 * 3,
                texture: "iron_pickaxe.png"
            },
            {
                name: "Golden Pickaxe",
                id: 'minecraft:golden_pickaxe',
                dv: 0,
                cost_buy: 40 * 3,
                cost_sell: 30 * 3,
                texture: "golden_pickaxe.png"
            },
            {
                name: "Diamond Pickaxe",
                id: 'minecraft:diamond_pickaxe',
                dv: 0,
                cost_buy: 60 * 3,
                cost_sell: 50 * 3,
                texture: "diamond_pickaxe.png"
            },
            {
                name: "Netherite Pickaxe",
                id: 'minecraft:netherite_pickaxe',
                dv: 0,
                cost_buy: 60 * 3 + 800,
                cost_sell: 50 * 3 + 800,
                texture: "netherite_pickaxe.png"
            }

        ],
        tool_shovels: [
            {
                name: "Wooden Shovel",
                id: 'minecraft:wooden_shovel',
                dv: 0,
                cost_buy: 2,
                cost_sell: 1,
                texture: "wooden_shovel.png"
            },
            {
                name: "Stone Shovel",
                id: 'minecraft:stone_shovel',
                dv: 0,
                cost_buy: 3,
                cost_sell: 1,
                texture: "stone_shovel.png"
            },
            {
                name: "Iron Shovel",
                id: 'minecraft:iron_shovel',
                dv: 0,
                cost_buy: 30,
                cost_sell: 20,
                texture: "iron_shovel.png"
            },
            {
                name: "Golden Shovel",
                id: 'minecraft:golden_shovel',
                dv: 0,
                cost_buy: 40,
                cost_sell: 30,
                texture: "golden_shovel.png"
            },
            {
                name: "Diamond Shovel",
                id: 'minecraft:diamond_shovel',
                dv: 0,
                cost_buy: 60,
                cost_sell: 50,
                texture: "diamond_shovel.png"
            },
            {
                name: "Netherite Shovel",
                id: 'minecraft:netherite_shovel',
                dv: 0,
                cost_buy: 60 + 800,
                cost_sell: 50 + 800,
                texture: "netherite_shovel.png"
            }

        ],
        tool_hoes: [
            {
                name: "Wooden Hoe",
                id: 'minecraft:wooden_hoe',
                dv: 0,
                cost_buy: 2 * 2,
                cost_sell: 1 * 2,
                texture: "wooden_hoe.png"
            },
            {
                name: "Stone Hoe",
                id: 'minecraft:stone_hoe',
                dv: 0,
                cost_buy: 3 * 2,
                cost_sell: 1 * 2,
                texture: "stone_hoe.png"
            },
            {
                name: "Iron Hoe",
                id: 'minecraft:iron_hoe',
                dv: 0,
                cost_buy: 30 * 2,
                cost_sell: 20 * 2,
                texture: "iron_hoe.png"
            },
            {
                name: "Golden Hoe",
                id: 'minecraft:golden_hoe',
                dv: 0,
                cost_buy: 40 * 2,
                cost_sell: 30 * 2,
                texture: "golden_hoe.png"
            },
            {
                name: "Diamond Hoe",
                id: 'minecraft:diamond_hoe',
                dv: 0,
                cost_buy: 60 * 2,
                cost_sell: 50 * 2,
                texture: "diamond_hoe.png"
            },
            {
                name: "Netherite Hoe",
                id: 'minecraft:netherite_hoe',
                dv: 0,
                cost_buy: 60 * 2 + 800,
                cost_sell: 50 * 2 + 800,
                texture: "netherite_hoe.png"
            }
        ],
        tool_swords: [{
            name: "Wooden Sword",
            id: 'minecraft:wooden_sword',
            dv: 0,
            cost_buy: 2 * 2,
            cost_sell: 1 * 2,
            texture: "wooden_sword.png"
        },
        {
            name: "Stone Sword",
            id: 'minecraft:stone_sword',
            dv: 0,
            cost_buy: 3 * 2,
            cost_sell: 1 * 2,
            texture: "stone_sword.png"
        },
        {
            name: "Iron Sword",
            id: 'minecraft:iron_sword',
            dv: 0,
            cost_buy: 30 * 2,
            cost_sell: 20 * 2,
            texture: "iron_sword.png"
        },
        {
            name: "Golden Sword",
            id: 'minecraft:golden_sword',
            dv: 0,
            cost_buy: 40 * 2,
            cost_sell: 30 * 2,
            texture: "golden_sword.png"
        },
        {
            name: "Diamond Sword",
            id: 'minecraft:diamond_sword',
            dv: 0,
            cost_buy: 60 * 2,
            cost_sell: 50 * 2,
            texture: "diamond_sword.png"
        },
        {
            name: "Netherite Sword",
            id: 'minecraft:netherite_sword',
            dv: 0,
            cost_buy: 60 * 2 + 800,
            cost_sell: 50 * 2 + 800,
            texture: "netherite_sword.png"
        }
        ],
        armor_helmet: [
            {
                name: "Leader Helmet",
                id: 'minecraft:leather_helmet',
                dv: 0,
                cost_buy: 10 * 5,
                cost_sell: 3 * 5,
                texture: "leather_helmet.tga"
            },
            {
                name: "Turtle Helmet",
                id: 'minecraft:turtle_helmet',
                dv: 0,
                cost_buy: 70 * 5,
                cost_sell: 50 * 5,
                texture: "turtle_helmet.png"
            },
            {
                name: "Chainmail Helmet",
                id: 'minecraft:chainmail_helmet',
                dv: 0,
                cost_buy: 35 * 5,
                cost_sell: 15 * 5,
                texture: "chainmail_helmet.png"
            },
            {
                name: "Iron Helmet",
                id: 'minecraft:iron_helmet',
                dv: 0,
                cost_buy: 30 * 5,
                cost_sell: 20 * 5,
                texture: "iron_helmet.png"
            },
            {
                name: "Golden Helmet",
                id: 'minecraft:golden_helmet',
                dv: 0,
                cost_buy: 40 * 5,
                cost_sell: 30 * 5,
                texture: "golden_helmet.png"
            },
            {
                name: "Diamond Helmet",
                id: 'minecraft:diamond_helmet',
                dv: 0,
                cost_buy: 60 * 5,
                cost_sell: 50 * 5,
                texture: "diamond_helmet.png"
            },
            {
                name: "Netherite Helmet",
                id: 'minecraft:netherite_helmet',
                dv: 0,
                cost_buy: 60 * 5 + 800,
                cost_sell: 50 * 5 + 800,
                texture: "netherite_helmet.png"
            }
        ],
        armor_chestplate: [
            {
                name: "Leather chestplate",
                id: 'minecraft:leather_chestplate',
                dv: 0,
                cost_buy: 10 * 8,
                cost_sell: 3 * 8,
                texture: "leather_chestplate.png"
            },
            {
                name: "Chainmail chestplate",
                id: 'minecraft:chainmail_chestplate',
                dv: 0,
                cost_buy: 35 * 8,
                cost_sell: 15 * 8,
                texture: "chainmail_chestplate.png"
            },
            {
                name: "Iron chestplate",
                id: 'minecraft:iron_chestplate',
                dv: 0,
                cost_buy: 30 * 8,
                cost_sell: 20 * 8,
                texture: "iron_chestplate.png"
            },
            {
                name: "Golden chestplate",
                id: 'minecraft:golden_chestplate',
                dv: 0,
                cost_buy: 40 * 8,
                cost_sell: 30 * 8,
                texture: "golden_chestplate.png"
            },
            {
                name: "Diamond chestplate",
                id: 'minecraft:diamond_chestplate',
                dv: 0,
                cost_buy: 60 * 8,
                cost_sell: 50 * 8,
                texture: "diamond_chestplate.png"
            },
            {
                name: "Netherite chestplate",
                id: 'minecraft:netherite_chestplate',
                dv: 0,
                cost_buy: 60 * 8 + 800,
                cost_sell: 50 * 8 + 800,
                texture: "netherite_chestplate.png"
            }
        ],
        armor_leggings: [
            {
                name: "Leather Leggings",
                id: 'minecraft:leather_leggings',
                dv: 0,
                cost_buy: 10 * 6,
                cost_sell: 3 * 6,
                texture: "leather_leggings.tga"
            },
            {
                name: "Chainmail Leggings",
                id: 'minecraft:chainmail_leggings',
                dv: 0,
                cost_buy: 35 * 6,
                cost_sell: 15 * 6,
                texture: "chainmail_leggings.png"
            },
            {
                name: "Iron Leggings",
                id: 'minecraft:iron_leggings',
                dv: 0,
                cost_buy: 30 * 6,
                cost_sell: 20 * 6,
                texture: "iron_leggings.png"
            },
            {
                name: "Golden Leggings",
                id: 'minecraft:golden_leggings',
                dv: 0,
                cost_buy: 40 * 6,
                cost_sell: 30 * 6,
                texture: "golden_leggings.png"
            },
            {
                name: "Diamond Leggings",
                id: 'minecraft:diamond_leggings',
                dv: 0,
                cost_buy: 60 * 6,
                cost_sell: 50 * 6,
                texture: "diamond_leggings.png"
            },
            {
                name: "Netherite Leggings",
                id: 'minecraft:netherite_leggings',
                dv: 0,
                cost_buy: 60 * 6 + 800,
                cost_sell: 50 * 6 + 800,
                texture: "netherite_leggings.png"
            }
        ],
        armor_boots: [
            {
                name: "Leather Boots",
                id: 'minecraft:leather_boots',
                dv: 0,
                cost_buy: 10 * 4,
                cost_sell: 3 * 4,
                texture: "leather_boots.tga"
            },
            {
                name: "Chainmail Boots",
                id: 'minecraft:chainmail_boots',
                dv: 0,
                cost_buy: 35 * 4,
                cost_sell: 15 * 4,
                texture: "chainmail_boots.png"
            },
            {
                name: "Iron Boots",
                id: 'minecraft:iron_boots',
                dv: 0,
                cost_buy: 30 * 4,
                cost_sell: 20 * 4,
                texture: "iron_boots.png"
            },
            {
                name: "Golden Boots",
                id: 'minecraft:golden_boots',
                dv: 0,
                cost_buy: 40 * 4,
                cost_sell: 30 * 4,
                texture: "golden_boots.png"
            },
            {
                name: "Diamond Boots",
                id: 'minecraft:diamond_boots',
                dv: 0,
                cost_buy: 60 * 4,
                cost_sell: 50 * 4,
                texture: "diamond_boots.png"
            },
            {
                name: "Netherite Boots",
                id: 'minecraft:netherite_boots',
                dv: 0,
                cost_buy: 60 * 4 + 800,
                cost_sell: 50 * 4 + 800,
                texture: "netherite_boots.png"
            }
        ],
        bucket: [
            {
                name: "Bucket",
                id: 'minecraft:bucket',
                dv: 0,
                cost_buy: 80,
                cost_sell: 30,
                texture: "bucket.png"
            },
            {
                name: "Water Bucket",
                id: 'minecraft:bucket',
                dv: 8,
                cost_buy: 90,
                cost_sell: 40,
                texture: "bucket_water.png"
            },
            {
                name: "Lava Bucket",
                id: 'minecraft:bucket',
                dv: 10,
                cost_buy: 90,
                cost_sell: 40,
                texture: "bucket_lava.png"
            },
            {
                name: "Powder Snow Bucket",
                id: 'minecraft:bucket',
                dv: 11,
                cost_buy: 600,
                cost_sell: 40,
                texture: "bucket_powder_snow.png"
            },
            {
                name: "Milk Bucket",
                id: 'minecraft:bucket',
                dv: 1,
                cost_buy: 90,
                cost_sell: 30,
                texture: "bucket_milk.png"
            },
            {
                name: "Bucket of Axolotl",
                id: 'minecraft:bucket',
                dv: 12,
                cost_buy: 90,
                cost_sell: 300,
                texture: "bucket_axolotl.png"
            },
            {
                name: "Bucket of Cod",
                id: 'minecraft:bucket',
                dv: 2,
                cost_buy: 100,
                cost_sell: 40,
                texture: "bucket_cod.png"
            },
            {
                name: "Bucket of Samalon",
                id: 'minecraft:bucket',
                dv: 3,
                cost_buy: 100,
                cost_sell: 40,
                texture: "bucket_samalon.png"
            },
            {
                name: "Bucket of Tropical Fish",
                id: 'minecraft:bucket',
                dv: 4,
                cost_buy: 100,
                cost_sell: 40,
                texture: "bucket_tropical.png"
            },
            {
                name: "Bucket of Pufferfish",
                id: 'minecraft:bucket',
                dv: 5,
                cost_buy: 100,
                cost_sell: 40,
                texture: "bucket_pufferfish.png"
            },
            {
                name: "Bucket of Tadpole",
                id: 'minecraft:bucket',
                dv: 13,
                cost_buy: 100,
                cost_sell: 40,
                texture: "bucket_tadpole.png"
            }
        ]
    },
    tool_shop = [
        {
            name: "Flint And Steel",
            id: 'minecraft:flint_and_steel',
            dv: 0,
            cost_buy: 40,
            cost_sell: 10,
            texture: "flint_and_steel.png"
        },
        {
            name: "Shears",
            id: 'minecraft:shears',
            dv: 0,
            cost_buy: 80,
            cost_sell: 30,
            texture: "shears.png"
        },
        {
            name: "compass",
            id: 'minecraft:compass',
            dv: 0,
            cost_buy: 130,
            cost_sell: 40,
            texture: "compass.png"
        },
        {
            name: "Clock",
            id: 'minecraft:clock',
            dv: 0,
            cost_buy: 170,
            cost_sell: 50,
            texture: "clock.png"
        },
        {
            name: "Fishing Rod",
            id: 'minecraft:fishing_rod',
            dv: 0,
            cost_buy: 50,
            cost_sell: 20,
            texture: "fishing_rod.png"
        },
        {
            name: "Trident",
            id: 'minecraft:trident',
            dv: 0,
            cost_buy: 500,
            cost_sell: 200,
            texture: "trident.png"
        }
    ];

const main_shop_ui = new ActionFormData()
    .title('§l§b§k||§r  §l§aShop  §b§k||')
    .button('§aNatural Block')
    .button('§aNatural Item')
    .button('§bBuilding Block')
    .button('§bTool & Armor')
    .button('§aPotion')
    .button('§aMiscellaneous')
    .button('§aPlugins'),
    natural_shop_ui = new ActionFormData()
        .title("§aNature Blocks Shop"),
    natural_item_shop_ui = new ActionFormData()
        .title("§aNature Items Shop"),
    tool_and_armor_ui = new ActionFormData()
        .title("§aTool & Armor")
        .button('§aAxe')
        .button('§aPickaxe')
        .button('§aHoe')
        .button('§aShovel')
        .button('§aSword')
        .button('§aHelmet')
        .button('§aChestplate')
        .button('§aLeggings')
        .button('§aBoots')
        .button('§aBuckets')
        .button('§aOther'),
    tools_axe_ui = new ActionFormData()
        .title("§aAxe"),
    tools_pickaxe_ui = new ActionFormData()
        .title("§aPickaxe"),
    tools_hoe_ui = new ActionFormData()
        .title("§aHoe"),
    tools_shovel_ui = new ActionFormData()
        .title("§aShovel"),
    tools_sword_ui = new ActionFormData()
        .title("§aSword"),
    armors_helmet_ui = new ActionFormData()
        .title("§aHelmet"),
    armors_chestplate_ui = new ActionFormData()
        .title("§aChestplate"),
    armors_leggings_ui = new ActionFormData()
        .title("§aLeggings"),
    armors_boots_ui = new ActionFormData()
        .title("§aBoots"),
    tools_bucket_ui = new ActionFormData()
        .title('§aBucket'),
    tools_other_ui = new ActionFormData()
        .title('§aOther');
//tools
for (let n of tool_shop) {
    tools_other_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.bucket) {
    tools_bucket_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.tool_axes) {
    tools_axe_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.tool_pickaxes) {
    tools_pickaxe_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.tool_hoes) {
    tools_hoe_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.tool_shovels) {
    tools_shovel_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.tool_swords) {
    tools_sword_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.armor_helmet) {
    armors_helmet_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.armor_chestplate) {
    armors_chestplate_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.armor_leggings) {
    armors_leggings_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of tools.armor_boots) {
    armors_boots_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/item§6 Sell§f:§a${n['cost_sell']}$/item`, `textures/ui/tool_and_weapon/${n['texture']}`);
}
for (let n of natural_items) {
    natural_item_shop_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/block§6 Sell§f:§a${n['cost_sell']}$/block`, `textures/ui/natural_item/${n['texture']}`);
}
for (let n of natural_blocks) {
    if (n.special_number) natural_shop_ui.button(`§2${n['name']}\n§bBuy§f:§a${numFormatter(n['cost_buy'])}$/block§6 Sell§f:§a${numFormatter(n['cost_sell'])}$/block`, `textures/ui/natural_shop/${n['texture']}`);
    else natural_shop_ui.button(`§2${n['name']}\n§bBuy§f:§a${n['cost_buy']}$/block§6 Sell§f:§a${n['cost_sell']}$/block`, `textures/ui/natural_shop/${n['texture']}`);
}

//===================================================================================================================================================================================================================================
//Function
//===================================================================================================================================================================================================================================

export function main_shop_ui_open(player) {
    main_shop_ui.show(player).then((r) => {
        if (r.isCanceled === true) return;
        switch (r.selection) {
            case 0: {
                natural_ui_open(player);
                break;
            }
            case 1: {
                natural_item_ui_open(player);
                break;
            }
            case 3: {
                tool_and_armor_ui_open(player);
                break;
            }
            default: {
                return;
            }
        }
    });
}
function natural_ui_open(player) {
    natural_shop_ui.show(player).then((r) => {
        if (r.isCanceled === true) return main_shop_ui_open(player);
        shop_ui_choose(player, natural_blocks[r.selection]);
    });
}
function natural_item_ui_open(player) {
    natural_item_shop_ui.show(player).then((r) => {
        shop_ui_choose(player, natural_items[r.selection]);

    });
}
function tool_and_armor_ui_open(player) {
    tool_and_armor_ui.show(player).then((r) => {
        if (r.isCanceled) return main_shop_ui_open(player);
        switch (r.selection) {
            case 0: {
                //axe
                tools_axe_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.tool_axes[r.selection]);
                });
                break;
            }
            case 1: {
                //pickaxe
                tools_pickaxe_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.tool_pickaxes[r.selection]);
                });
                break;
            }
            case 2: {
                ///hoe
                tools_hoe_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.tool_hoes[r.selection]);
                });
                break;
            }
            case 3: {
                //shovel
                tools_shovel_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.tool_shovels[r.selection]);
                });
                break;
            }
            case 4: {
                //sword
                tools_sword_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.tool_swords[r.selection]);
                });
                break;
            }
            case 5: {
                //helmet
                armors_helmet_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.armor_helmet[r.selection]);
                });
                break;
            }
            case 6: {
                //chestpalte
                armors_chestplate_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.armor_chestplate[r.selection]);
                });
                break;
            }
            case 7: {
                //leggings
                armors_leggings_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.armor_leggings[r.selection]);
                });
                break;
            }
            case 8: {
                //boots
                armors_boots_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.armor_boots[r.selection]);
                });
                break;
            }
            case 9: {
                //bucket
                tools_bucket_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tools.bucket[r.selection]);
                });
                break;
            }
            case 10: {
                //other
                tools_other_ui.show(player).then((r) => {
                    if (r.isCanceled) return tool_and_armor_ui_open(player);
                    shop_ui_choose(player, tool_shop[r.selection]);
                });
                break;
            }
            default: {
                return;
            }
        }
    });
}
//===================================================================================================================================================================================================================================
//Controller
//===================================================================================================================================================================================================================================

function shop_ui_choose(player, item_data) {
    cache[player.nameTag] = new ActionFormData()
        .title(`§2Buy ${item_data['name']}`)
        .button(`§aBuy ×1\n§3${item_data['cost_buy'] * 1}$`)
        .button(`§aBuy ×16\n§3${item_data['cost_buy'] * 16}$`)
        .button(`§aBuy ×32\n§3${item_data['cost_buy'] * 32}$`)
        .button(`§aBuy ×64\n§3${item_data['cost_buy'] * 64}$`)
        .button(`§aBuy more\n§3${item_data['cost_buy']}$ per item`)
        .button(`§aSell ×1\n§3${item_data['cost_sell'] * 1}$`)
        .button(`§aSell ×16\n§3${item_data['cost_sell'] * 16}$`)
        .button(`§aSell ×32\n§3${item_data['cost_sell'] * 32}$`)
        .button(`§aSell ×64\n§3${item_data['cost_sell'] * 64}$`)
        .button(`§aSell more\n§3${item_data['cost_sell']}$ per item`)
        .show(player).then((r) => {
            if (r.isCanceled) return main_shop_ui_open(player);
            if (r.selection === 0) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${buyItem(player, item_data['id'], 1, item_data['dv'], item_data['cost_buy'], item_data['name'])['error']}"}]}`);
            if (r.selection === 1) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${buyItem(player, item_data['id'], 16, item_data['dv'], item_data['cost_buy'], item_data['name'])['error']}"}]}`);
            if (r.selection === 2) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${buyItem(player, item_data['id'], 32, item_data['dv'], item_data['cost_buy'], item_data['name'])['error']}"}]}`);
            if (r.selection === 3) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${buyItem(player, item_data['id'], 64, item_data['dv'], item_data['cost_buy'], item_data['name'])['error']}"}]}`);
            if (r.selection === 4) shop_ui_buy_more_option(player, item_data);
            if (r.selection === 5) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${sellItem(player, item_data['id'], 1, item_data['dv'], item_data['cost_sell'], item_data['name'])['error']}"}]}`);
            if (r.selection === 6) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${sellItem(player, item_data['id'], 16, item_data['dv'], item_data['cost_sell'], item_data['name'])['error']}"}]}`);
            if (r.selection === 7) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${sellItem(player, item_data['id'], 32, item_data['dv'], item_data['cost_sell'], item_data['name'])['error']}"}]}`);
            if (r.selection === 8) runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${sellItem(player, item_data['id'], 64, item_data['dv'], item_data['cost_sell'], item_data['name'])['error']}"}]}`);
            if (r.selection === 9) shop_ui_sell_more_option(player, item_data);
        });
}

function shop_ui_sell_more_option(player, item_data) {
    cache[player.nameTag] = new ModalFormData()
        .title(`§aSell more ${item_data['name']}`)
        .slider("Count", 1, 64 * 12, 1, 1)
        .toggle("Sell all(turn this on)",
            false)
        .show(player).then((r) => {
            if (r.isCanceled) return shop_ui_choose(player, item_data);
            let count_sellter = r.formValues[0];
            if (r.formValues[1] === true) count_sellter = 'all';
            runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${sellItem(player, item_data['id'], count_sellter, item_data['dv'], item_data['cost_sell'], item_data['name'])['error']}"}]}`);
        });
}
function shop_ui_buy_more_option(player, item_data) {
    cache[player.nameTag] = new ModalFormData()
        .title(`§aBuy more ${item_data['name']}`)
        .slider("Count", 1, 64 * 12, 1, 1)
        .show(player).then((r) => {
            if (r.isCanceled) return shop_ui_choose(player, item_data);
            runCommand(`tellraw "${player.nameTag}" {"rawtext":[{"text":"${buyItem(player, item_data['id'], r.formValues[0], item_data['dv'], item_data['cost_buy'], item_data['name'])['error']}"}]}`);
        });
}