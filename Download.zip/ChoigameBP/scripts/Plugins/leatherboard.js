import {
    getEntityTag,
    getScore
} from "../system/system.js";
import Database from "../system/database.js";
import {
    world
} from "mojang-minecraft";
import {
    numFormatter,
    alignLeft
} from "../system/data_format.js";

const PlayerData = new Database('LBPData');
let bool = true;

export function updateLeaderboard(entity) {
    if (bool === false) return;
    bool = false;
    let nameLB = getEntityTag(entity, "nameLB:") ?? '§cNo Name';
    let objective = getEntityTag(entity, "objective:");
    let show = getEntityTag(entity, "show_all_time:") ?? false;
    let player_scores = {}
    for (const player of world.getPlayers()) {
        player_scores[player.nameTag] = getScore(player, objective);
    }
    let sortable = [];
    for (const player in player_scores) {
        sortable.push([player, player_scores[player]]);
    }
    if (show === true) {
        let saveData = PlayerData.get(`${objective}`) ?? [];
        for (let arr of sortable) {
            if (saveData.filter(arr1 => arr1[0].includes(arr[0]))) arr1[1] = arr[1];
            else saveData.push(arr);
        }
        sortable = saveData;
    }
    PlayerData.set(`${objective}`, []);
    PlayerData.update(`${objective}`, sortable);
    let str = sortable.sort(function(a, b) {
        return b[1] - a[1];
    });
    str.map(array => {
        array[0] = alignLeft(array[0], 18);
        array[1] = alignLeft(numFormatter(array[1]), 7);
    });
    let sorted_score = [];
    sorted_score[0] = `${nameLB}`;
    sorted_score[1] = ` §bTop         §6Name         §eScore `;
    let counter = 0;
    let co;
    for (const array of str) {
        counter += 1;
        co = alignLeft(`#${counter}`, 3);
        sorted_score[counter + 1] = `§b${co} §a${array.join(' §c ')}`;
    }
    entity.nameTag = `${sorted_score.slice(0, 12)?.join("\n")}`;
    bool = true;
}