/**
==============================================
* @author Choigame123
* Discord: Choigame_123
* YouTube: https://youtube.com/channel/UCngsKdvRaKrMZG-ar2ToAmg
*/

import {
    world,
    Player
} from "mojang-minecraft";
import {
    setting
} from "../config.js";
let ccmdpf = setting.ccmdpf;

/**
* Runs a tellraw command
* @param {object} command a mojang-minecraft player
* @param {string} jsonString {"text": ""} | {"selector": ""} | {"score":{"name": "", "objective": ""}}
* @return {void}
* @example tellrawCommand(player, `{"text":"name:"},{"selector":"*"}`)
*/
export function tellrawCommand(player, jsonString) {
    runCommand(`tellraw "${player.nameTag}" {"rawtext":[${jsonString}]}`);
}

/**
* Real-time for something
* @param {boolean} bool true = show timezone
* @return {string}
* @example timeUpdate()
*/
export function timeUpdate(bool = false) {
    const d = new Date();
    let [hz,mz,sz,gmts,time,gmt] = [d.getHours(),d.getMinutes(),d.getSeconds(),addGMT(d.getTimezoneOffset()),["","",""],''];
    if (hz < 10) time[0] = `0${hz}`; else time[0] = hz;
    if (mz < 10) time[1] = `0${mz}`; else time[1] = mz;
    if (sz < 10) time[2] = `0${sz}`; else time[2] = sz;
    if (gmts > 0) gmt = `+${gmts}`; else gmt = gmts;
    //change you time format here
    if (!bool) return `§b${gmt} §a${time.join('§f:§a')}§r`;
    return `${time.join('§f:§b')}§r`;
}
function addGMT(data) {
    if (data > 0) {
        data = ((data / 60) * -1)} else if (data < 0) {
        data = ((data / 60) * -1)}
    return data;
}

/**
* get entity tag
* @param {object} entity a mojang-minecraft entity
* @param {string} perfix perfix for tag you need
* @example getEntityTag(entity, "rank:")
* @return {array}
*/
export function getEntityTag(entity, perfix) {
    let tags = entity.getTags()?.filter(tag => tag.startsWith(perfix))?.map(tag => tag.replace(perfix, ''))
    return tags ?? undefined;
}

/**
* Get rank(s) for player(only)
* @param {object} player player class
* @param {string} chat_rank_perfix
* @param {string} first_rank
* @param {string} multirankSign
* @return {array}
*/
export function getRanks(player, chat_rank_perfix, first_rank, multirankSign) {
    if (!player instanceof Player) return;
    let ranks = player.getTags().filter(tag => tag.startsWith(chat_rank_perfix))?.map(tag => tag.replace(chat_rank_perfix, '')).join(multirankSign);
    return ranks ? ranks: first_rank;
}

/**
* Get region(s) for player(only)
* @param {object} player player class
* @param {string} chat_region_perfix
* @return {array}
*/
export function getRegion(player, chat_region_perfix) {
    if (!player instanceof Player) return;
    let regions = player.getTags().filter(tag => tag.startsWith(chat_region_perfix)).map(tag => tag.replace(chat_region_perfix, ''));
    if (regions.length > 1) {
        runCommand('tellraw @a {"rawtext":[{"text":"§c[Sever][ChatRegion][Error][Chat Region Tags] Can only have one region\n§c[Sever][ChatRegion][Auto Repaid] Get first tag has region!"}]}');
        return regions[0];
    }
    return regions ? regions[0] : undefined;
}

export function runCommands(commands) {
    commands.forEach((cmd) => runCommand(cmd));
}

/**
* Run minecraft command
* @param {string} command a minecraft command
* @return {array}
*/
export function runCommand(command) {
    try {
        return {error: false, statusMessage: world.getDimension('overworld').runCommand(command).statusMessage};
    } catch (e) {return {error: true};}
}

/**
* Get score for player
* @param {object} player player class
* @param {string} objective
* @param {{number, number}}
* @return {number}
*/
export function getScore(player, objective, {
    minimum, maximum
} = {}) {
    const data = runCommand(
        `scoreboard players test "${player.nameTag}" ${objective} ${
        minimum ? minimum: "*"
        } ${maximum ? maximum: "*"}`
    );
    if (!data.statusMessage) return 0;
    return parseInt(data.statusMessage.match(/-?\d+/)[0]);
}

/**
* Get score for entity
* @param {object} player player class
* @param {string} objective
* @param {{number, number}}
* @return {number}
*/
export function getEntityScore(entity, objective, {
    minimum, maximum
} = {}) {
    const data = runCommand(
        `scoreboard players test @e[name="${entity.nameTag},type=!player] ${objective} ${
        minimum ? minimum: "*"
        } ${maximum ? maximum: "*"}`
    );
    if (!data.statusMessage) return 0;
    return parseInt(data.statusMessage.match(/-?\d+/)[0]);
}

let time = {};
/**
* Open form when you want open it in chat
* @param {object} player mojang-minecraft player
* @param {Function} func function to openform you want (arg is player)
* @returns {any}
*/
export function damgeToForm(player, func) {
    if (getGamemode(player) == 'creative') {
        setGamemode(player, 'survival');
        runCommand(`damage "${player.nameTag}" 0 entity_attack`);
        setGamemode(player, 'creative');
    } else
        runCommand(`damage "${player.nameTag}" 0 entity_attack`);
    time[player.nameTag] = 10;
    let wait = world.events.tick.subscribe((data) => {
        time[player.nameTag] -= 1;
        if (time[player.nameTag] < 0) {
            world.events.tick.unsubscribe(wait);
            return func(player);
        }
    });
}

/**
* Run minecraft command but on player
* @param {object} player a mojang-minecraft player
* @param {string} cmd minecraft command
* @return {object}
*/
function executeCommand(player, cmd) {
    try {
        return {
            statusMessage: player.runCommand(cmd).statusMessage,
            err: false
        };
    } catch (e) {return {error: true};}
}

/**
* Set gamemode for player
* @param {object} player mojang-minecraft player
* @param {"creative"|"survival"|"adventure"} gamemode
* @returns {void}
*/
export function setGamemode(player, gamemode) {
    const command = executeCommand(player, `gamemode ${gamemode}`);
    if (command.err) return console.error("setGamemode Error: " + command.statusMessage);
}

/**
* Get gamemomde for player
* @param {object} player mojang-minecraft player
* @returns {"creative"|"survival"|"adventure"|"unknown"}
*/
export function getGamemode(player) {
    let [a, s, c] = ["a","s","c"].map((gm) => gm = runCommand(`testfor @a[name="${player.nameTag}",m=${gm}]`).error);
    return (!a) ? 'adventure' : (!s) ? 'survival' : (!c) ? 'creative' : 'unknown';
}