import {world} from 'mojang-minecraft';

function textToBinary(text){return text.split('').map((char) => {return char.charCodeAt(0).toString(2);}).join(' ');};
function binaryToText(binary){return binary.split(' ').map((char) => {return String.fromCharCode(parseInt(char, 2));}).join('');};
function runCommand(command){try{return {error: false,statusMessage: world.getDimension('overworld').runCommand(command).statusMessage};}catch(e){};};
let [counter, TABLE] = [0, []];
/**
*Database
*@athour Choigame123
*/
export default class Database {
    constructor(table){try{runCommand('scoreboard objectives add database dummy');}catch(error){};this.table =table;this.counter =counter;counter++;TABLE[this.counter]=table;};
    getJSON(){try{return world.scoreboard.getObjective('database')?.getParticipants()?.filter((v) => v.type === 3)?.map((v) => v = v.displayName).filter((v) => (v.match(/(?<=binDB\(){'table':'[\w\d\s]+','key':'[\w\d\s]+'}:[0-1\s]+(?=\))/gm))?.length === 1)?.map((v) => v = v.replace(/'/g, '"')).filter(v => JSON.parse(v.match(/\{"table":"[\w\d\s]+","key":"[\w\d\s]+"\}/gm)[0]).table === this.table)?.map(v => v = {key: JSON.parse(v.match(/\{"table":"[\w\d\s]+","key":"[\w\d\s]+"\}/gm)[0]).key,table: JSON.parse(v.match(/\{"table":"[\w\d\s]+","key":"[\w\d\s]+"\}/gm)[0]).key, data: JSON.parse(binaryToText(v.match(/(?<=\}:)[0-1\s]+(?=\))/gm)[0].trim())), bin: v.match(/(?<=\}:)[0-1\s]+(?=\))/gm)[0].trim()});}catch(e){console.warn(new Error(`Database:getJSON():${e} ${e.stack}`))};};
    hasTable(table){return TABLE.includes(table);};
    hasKey(key){return this.getJSON()?.filter(v => v.key === key).length > 0;};get(key){try{if(!this.hasKey(key))return new Error(`Database:No key with name: ${key}`);return this.getJSON().filter((v) => v.key === key)[0];}catch(e){console.warn(new Error(`Database:get():${e} ${e.stack}`))};};
    allKey(){try{return this.getJSON();}catch(e){console.warn(new Error(`Database:allKey():${e} ${e.stack}`));};};
    get(key){try{let $data = this.getJSON().filter((v) => v.key === key)[0];return $data ? $data : undefined;}catch(e){console.warn(new Error(`Database:get():${e} ${e.stack}`));};}
    set(key, value){if(this.hasKey(key))return false;try{runCommand(`scoreboard players set "binDB({'table':'${this.table}','key':'${key}'}: ${textToBinary(JSON.stringify(value))})" database 0`);return true;}catch(e){console.warn(new Error(`Database:set():${e} ${e.stack}`));};};
    update(key, value){try{this.remove(key);this.set(key, value);}catch(e){console.warn(new Error(`Database:update():${e} ${e.stack}`));};};
    remove(key){try{this.getJSON().filter(v => v.key === key).forEach(v => {try{runCommand(`scoreboard players reset "binDB({'table':'${this.table}','key':'${key}'}: ${v.bin})" database`);return true;}catch(e){}});}catch(e){console.warn(new Error(`Database:remove():${e} ${e.stack}`));};};
    clear(){try{this.getJSON().forEach((v) => this.remove(v.key));return true;}catch(e){console.warn(new Error(`Database:clear():${e} ${e.stack}`));return false;};}
};
