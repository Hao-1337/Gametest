export function numFormatter(num, digits = 2) {
    const lookup = [{
        value: 1,
        symbol: ""
    },
        {
            value: 1e3,
            symbol: "K"
        },
        {
            value: 1e6,
            symbol: "M"
        },
        {
            value: 1e9,
            symbol: "B"
        }];
    const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
    let item = lookup.slice().reverse().find(function(item) {
        return num >= item.value;
    });
    return item ? (num / item.value).toFixed(digits).replace(rx, "$1") + item.symbol: "0";
}
export function alignLeft(string, length = 16) {
    let out = string,
        length1 = string.replace(/§[0-9a-forlkg]/g, "");
    if (length1.length < length) {
        for (var i = 0; i < length - string.length; i++) {
            out += " ";
        }
    }
    out = string;
    return out;
}