//path: /storage/emulated/0/Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds/Script_world_/behavior_packs/Choigame12/

import {
    updateLeaderboard
} from "./Plugins/leatherboard.js";
import {
    onChat
} from "./Plugins/Chat/main.js";
import {
    alignLeft
} from "./system/data_format.js";
import {
    setting
} from "./config.js";
import {
    world,
    EntityQueryOptions,
    Items,
    ItemStack,
    Location,
    BlockLocation
} from "mojang-minecraft";
import {
    openForm
} from "./Plugins/Form/main.js";
import {
    runCommands,
    runCommand as runCmd,
    getRanks,
    timeUpdate
} from "./system/system.js";
import {
    nuke
} from "./AntiHackPlugins/block_break_check.js";
import {
    banned_item
} from "./AntiHackPlugins/inventory_check.js";
import {
    kill_arura
} from "./AntiHackPlugins/kill_arura_check.js";
import {
    reach_check
} from "./AntiHackPlugins/reach_check.js";
import './system/database.js';
import './Plugins/plot.js';
import './Plugins/Chest Form/main.js';

try {
    //Anti hack
    nuke();
    banned_item();
    kill_arura();
    reach_check();
}
catch (error) {
    console.warn(`${error}\n${error.stack}`);
}

const velocity = (p1, p2) => {
    return Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2 + (p1.z - p2.z) ** 2);
}
const health = (player) => {
    return player.getComponent("minecraft:health").current;
}
let chat_rank_perfix = setting.chat_rank_perfix,
frist_rank = setting.frist_rank,
command_perfix = setting.command_perfix,
updateTime = setting.LBdelay,
log = {},
updateTime1 = 0,
updateTime2 = 0,
s1 = undefined,
lore = ['', `§aThis is powerful item,\n use for open UI`, `§cIf you lose it, you can\n use the command:§f "${command_perfix}get_ui_item"`, '', '', '§8Plugins by Choigame123'];
const options = new EntityQueryOptions();
options.type = "choigame:floating_text";
options.tags = ['is_leaderboard'];
const options1 = new EntityQueryOptions();
options1.type = "choigame:floating_text";
options1.tags = ['is_player_board'];

world.events.beforeItemUse.subscribe((data) => {
    let item = data.item;
    if (item.id === 'choigame123:ui_open') {
        openForm(data.source, true);
    }
});
world.events.tick.subscribe(({
    deltaTime
}) => {
    try {
        let players = world.getDimension('overworld').getPlayers(),
        p_count = 0;
        for (let player of players) {
            if (!player.hasTag('item_done')) {
                player.runCommand(`replaceitem entity @s slot.hotbar 0 choigame123:ui_open 1 0 {"minecraft:item_lock":{"mode":"lock_in_inventory"}, "minecraft:keep_on_death":{}}`);
                let item = player.getComponent("minecraft:inventory").container.getItem(0);
                while (item.getLore().length > 0) {
                    item.setLore(lore);
                }
                player.addTag('item_done');
            }
            p_count++;
            let location = player.location,
            entity1 = [...world.getDimension(`overworld`).getEntities(options1)].filter(x => x.hasTag(`name:${player.nameTag}`));
            if (entity1.length === 0) {
                let entity2 = world.getDimension('overworld').spawnEntity("choigame:floating_text", new BlockLocation(location.x, location.y, location.z));
                entity2.addTag('is_player_board');
                entity2.addTag(`name:${player.nameTag}`);
            } else for (let entity3 of entity1) {
                let health = player.getComponent('minecraft:health');
                entity3.teleport(new Location(location.x, location.y + 2.5, location.z), world.getDimension('overworld'), 0, 0);
                entity3.nameTag = `[${getRanks(player, chat_rank_perfix, frist_rank, "§r,")}]\n§aHealth:§f${health.current}/${health.value}`;
            }
        }
        if (updateTime1 <= -20) {
            updateTime1 = 0;
            let tps = Number.parseFloat(1 / deltaTime).toFixed(2);
            for (let player1 of players) {
                let new_pos = player1.location;
                if (!log[player1.nameTag]) log[player1.nameTag] = new_pos;
                let speed = velocity(new_pos, log[player1.nameTag]);
                log[player1.nameTag] = new_pos;
                runCommands([
                    'scoreboard objectives add tps dummy "§aTPS Counter"',
                    `scoreboard players set "int" tps ${tps.split('.')[0]}`,
                    `scoreboard players set "decimal" tps ${tps.split('.')[1]}`,
                    `titleraw "${player1.nameTag}" title {"rawtext":[{"text":"§g==== §6Sever Status §g====\n  §a${alignLeft(`Player count§f:§e ${p_count}/30`, 22)}\n  §a${alignLeft(`Current tps§f:§e ${tps}`, 22)}\n  ${alignLeft(`§aReal-time§f:§b${timeUpdate(true)}§8§l§o+7§r`, 22)}\n§f§g===== §6You Status §g=====\n  §a${alignLeft(`Name§f:§r ${player1.nameTag}`, 22)}"},{"text":"\n  §a${alignLeft(`Speed§f:§e ${speed.toFixed(2)}`, 22)} m/s\n  §a${alignLeft(`Health§f:§2 ${health(player1)}`, 22)}"}]}`,
                    `scoreboard objectives add timer dummy`
                ]);
                let date = new Date(),
                s = date.getSeconds();
                if (!s1) s1 = s;
                if (s1 !== s) {
                    s1 = s;
                    runCmd(`scoreboard players add "timer" timer 1`);
                }
            }
        }
        if (updateTime2 < -72e3) {
            updateTime2 = 0;
            runCommands([
                `tellraw @a {"rawtext": [{"text": "§aAdded an hour passed, total time:"},{"score":{"name":"timer","objective":"timer"}},{"text":"s"}]}`
            ]);
        }
        if (updateTime < 0) {
            updateTime = setting.LBdelay;
            let entities = world.getDimension('overworld').getEntities(options);
            if (entities) for (const entity of entities) updateLeaderboard(entity);
        }
        updateTime -= 1;
        updateTime1 -= 1;
        updateTime2 -= 1;
    }
    catch (error) {
        console.warn(`${error}, ${error.stack}`);
    }
});

onChat();

/**
function newObj(obj) {
if (typeof obj != "object") return obj;
const _a = Array.isArray(obj) ? []: {};

for (const k in obj) _a[k] = typeof obj == "object" ? newObj(obj[k]): obj[k];
return _a;
}

function toString(obj) {
return JSON.stringify(newObj(obj), void 0, 3);
}
*/