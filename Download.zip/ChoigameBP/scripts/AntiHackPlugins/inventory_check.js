import {
    ItemStack,
    world,
    MinecraftEnchantmentTypes,
    MinecraftItemTypes,
} from "mojang-minecraft";
import {
    blockBan,
    config,
    onHack
} from "../config.js";

const MinecraftEnchantments = Object.values(MinecraftEnchantmentTypes),
empty = new ItemStack(MinecraftItemTypes.air),
clear = (i, inventory) => inventory.setItem(i, empty),
getInv = (player) => player.getComponent("minecraft:inventory").container,
gI = (i, inventory) => inventory.getItem(i) ?? empty,
invItems = (iv) => Array.from({length: iv.size}, (e, i) => gI(i, iv)),
enchVal = (i, n, e) => !i.canAddEnchantment(n) && n.level != e.maxLevel;

export const banned_item = () => world.events.tick.subscribe(() => {
    for (const player of [...world.getPlayers()]) {
        if (player.hasTag(config.byPassTag)) continue;
        let inventory = getInv(player);
        for (const [i, item] of invItems(inventory).entries()) {
            const itemEnchants = item.getComponent("enchantments").enchantments;
            if (blockBan.includes(item.id)) {
                clear(i, inventory);
                //flaged
                onHack(player);
            }
            for (const e of MinecraftEnchantments) {
                const ench = itemEnchants.getEnchantment(e);
                if (ench && enchVal(itemEnchants, ench, e)) {
                    clear(i, inventory);
                    //flaged
                    onHack(player);
                }
            }
        }
    }
});
