import {
    Player,
    world
} from "mojang-minecraft";
import {
    config,
    onHack
} from "../config.js";

const log = {}, i = {};
export const fly_check = () => world.events.tick.subscribe((data) => {
    let array = [...world.getDimension("overworld").getPlayers()]
    for(let player of array) {
        if (player.hasTag('isJumping') || player.hasTag('isOnGround') || i[player.nameTag] !== 0 ) continue;
        log[player.nameTag] = Date.now();
        i[player.nameTag] = 0;
        do {
            i[player.nameTag]++;
            console.warn(i[player.nameTag]);
            if (Date.now() - log[player.nameTag] > 15) {
                //flaged
                onHack(player);
            }
        } while (!player.hasTag('isOnGround') || !player.hasTag('isJumping') || i[player.nameTag] > 20);
    };
});
world.events.playerLeave.subscribe((data) => {
    delete log[data.playerName];
    delete i[data.playerName];
    });