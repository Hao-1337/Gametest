import {
    MinecraftBlockTypes,
    world,
} from "mojang-minecraft";
import {
    onHack,
    config
} from "../config.js"
const MAX_REACH_LIMIT = 7;
const byPassTag = config.byPassTag;

function isReach(p1, p2) {
    return (
        Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2 + (p1.z - p2.z) ** 2) >
        MAX_REACH_LIMIT
    );
}
export const reach_check = () => {
    world.events.beforeItemUseOn.subscribe((data) => {
        if (!isReach(data.source.location, data.blockLocation) || data.source.hasTag(byPassTag)) return;
        // flagged
        data.cancel = true;
        onHack(data.source);
    });

    world.events.blockBreak.subscribe((data) => {
        if (!isReach(data.player.location, data.block.location) || data.player.hasTag(byPassTag)) return;
        // flagged
        onHack(data.player);
        data.dimension
        .getBlock(data.block.location)
        .setPermutation(data.brokenBlockPermutation);
    });

    world.events.blockPlace.subscribe((data) => {
        if (!isReach(data.player.location, data.block.location) || data.player.hasTag(byPassTag)) return;
        // flagged
        onHack(data.player);
        data.dimension
        .getBlock(data.block.location)
        .setPermutation(MinecraftBlockTypes.air);
    });

    world.events.entityHit.subscribe((data) => {
        if (data.hitEntity) {
            if (!isReach(data.entity.location, data.hitEntity.location)) return;
        } else if (data.hitBlock) {
            if (!isReach(data.entity.location, data.hitBlock.location)) return;
        } else {
            return;
        }
        //flagged
        // do something here maybe flag or send a message to staff
    });
}