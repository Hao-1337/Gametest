import {
    world,
    Location,
    EntityRaycastOptions
} from "mojang-minecraft";
import {
    config,
    onHack
} from "../config.js";
const getoption = new EntityRaycastOptions();
getoption.maxDistance = 7;
let log = [],
log_length = 8;

function same(array = log) {
    for (let counter = 0;counter < array.length;counter++) {
        let e = array[counter];
        for (let object of array) {
            if (e["source"].nameTag === obiect["source"].nameTag && e["timer"] === obiect["timer"])
            return {bool: true, source: e["source"]};
        }
    }
    return {bool: false};
}
export const kill_arura = () => world.events.entityHurt.subscribe(
    (data) => {
        //get hit while unseen
        let source = data.damagingEntity,
            target = data.hurtEntity,
            damage = data.damage;
        if (!source) return;
        if (source.id !== "minecraft:player" || damage === 0 || source.hasTag(config.byPassTag)) return;
        log.push({source: source, timer: Date.now()});
        let d = same();
        //multi atack
        if (d.bool && !d.source.hasTag(config.byPassTag)) {
            //flaged
            onHack(d.source);
        }
        if (log.length >= log_length) {log = []; c = 0;}
        let target2 = [...world.getDimension(source.dimension.id).getEntitiesFromRay(new Location(source.location.x, source.location.y, source.location.z), source.viewVector, getoption)];
        console.warn(`Kill arura check target: ${target.id} , target from source: ${target2}`);
        if (target2.length !== 0) for (let check of target2) {
            if (check.nameTag === target.nameTag) return;
        }
        //flaged
        onHack(source);
    }
);
